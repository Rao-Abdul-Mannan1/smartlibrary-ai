# SmartLib AI

**AI-Powered Smart Library Management System**
*"Your Library, Anywhere."*

A full-stack library management system built for a college mini-project brief: students manage and renew issued books from their phones by scanning a QR code, with an AI assistant answering questions from real library data, and a full admin/librarian back office behind it.

This is a real, runnable application — not a mockup. Every button does what it says; every dashboard number comes from a live database query.

---

## 1. Project Overview

Two kinds of users:

- **Students** register with a verified college email, view their issued books, scan a book's QR code to check renewal eligibility and renew it, search the catalog, reserve unavailable books, track fines, and ask an AI assistant about their account.
- **Admins / librarians** manage the book catalog (with auto-generated QR codes), issue and return books, manage students, oversee renewals/fines/reservations, configure library rules, and view reports and an audit log.

## 2. Features

**Student:** register & verify college email · dashboard with live stats · scan-to-renew via camera QR (with manual entry fallback) · book search & filters · book detail + reserve · AI assistant (chat) · renewal history · reservations · fines · notifications · profile · library rules.

**Admin:** dashboard with charts · book CRUD with auto QR generation, download & print · combined issue/return flow (with scanning) · student management (search, add, block/unblock, view profile) · renewal management · fine management (mark paid/waived) · reservation queue · configurable library settings · reports (most borrowed, most active students, overdue, fine collection, availability) · audit log.

**AI:** a controlled-function-calling assistant (OpenAI or Gemini) that can look up a student's books, check renewal eligibility, search the catalog, check fines, explain library rules, and recommend books — always from real backend data, never invented, and never able to perform a renewal itself (see [Security](#8-security) and [How AI Works](#7-how-ai-works)).

## 3. Technology Stack

| Layer | Choice |
|---|---|
| Backend | Node.js + Express |
| Database | MySQL 8+ (raw parameterized SQL via `mysql2`, no ORM) |
| Auth | JWT + bcrypt password hashing |
| QR codes | `qrcode` (generation) + `html5-qrcode` (camera scanning, client-side) |
| AI | OpenAI Chat Completions API or Google Gemini API, provider-agnostic |
| Email | `nodemailer`, with a console/dev fallback if no SMTP is configured |
| Frontend | Plain HTML/CSS/JS, mobile-first, no build step, Chart.js (CDN) for admin charts |

**Why no framework/ORM?** This keeps the codebase transparent for a viva/demo — every SQL query and every request handler is readable end to end, and there's no build step standing between you and the code. See `backend/services/` for where the interesting logic lives.

## 4. Architecture

```
smartlib-ai/
├── frontend/          Static HTML/CSS/JS — public pages, student/, admin/
├── backend/
│   ├── config/        env.js, db.js (MySQL pool + transaction helper)
│   ├── controllers/   one per resource — thin, calls services/models
│   ├── models/        parameterized SQL query functions, one file per table
│   ├── services/       business logic (renewal rules, fines, QR, email, AI)
│   ├── middleware/     auth (JWT + role guard), rate limiting, upload, errors
│   ├── routes/         Express routers, mounted in server.js
│   └── scripts/seed.js  demo data generator
├── database/schema.sql  full DDL
├── ai/                 system prompt + tool-schema definitions (shared by aiService)
└── uploads/             generated QR codes + uploaded cover images
```

**Renewal is the one flow worth understanding first.** `backend/services/renewalRules.js` is a *pure function* — no database, no I/O — that takes a snapshot of facts (renewal count, reservations, overdue status, fines, account status) and returns eligible/not-eligible with a reason. `backend/services/renewalService.js` wraps it: it fetches the facts, calls the pure function, and — if eligible — performs the renewal inside a single SQL transaction. The AI assistant, the student-facing scan flow, and the admin renewal screen all funnel through this one function. Run `npm test` to see it (and the fine calculator, and the book-title fuzzy matcher) unit-tested directly.

## 5. Database Setup

1. Install MySQL 8+ and make sure it's running.
2. Create the schema:
   ```bash
   mysql -u root -p < database/schema.sql
   ```
   This creates the `smartlib_ai` database and all 15 tables (see the file for the full DDL — `users`, `students`, `admins`, `books`, `categories`, `issues`, `renewals`, `fines`, `reservations`, `notifications`, `library_settings`, `email_verifications`, `ai_conversations`, `ai_messages`, `audit_logs`).
3. Seed realistic demo data (categories, a real textbook catalog with generated QR codes, one admin, and three demo students in different states):
   ```bash
   npm run seed
   ```
   This prints the demo login credentials when it finishes.

## 6. Environment Variables

Copy `.env.example` to `.env` and fill it in:

```bash
cp .env.example .env
```

Every variable is documented inline in `.env.example`, including:

- `DB_HOST` / `DB_PORT` / `DB_NAME` / `DB_USER` / `DB_PASSWORD` — your MySQL connection
- `JWT_SECRET` — generate a real one for anything beyond local testing: `openssl rand -hex 32`
- `COLLEGE_EMAIL_DOMAIN` — the only email domain registration will accept (e.g. `@college-domain.ac.in`)
- `AI_PROVIDER` / `AI_API_KEY` / `AI_MODEL` — see below
- `MAIL_*` — see below

**Never commit `.env`.** It's already in `.gitignore`.

## 7. How AI Works

The AI assistant never touches the database directly and never decides a renewal itself (see [Security](#8-security)). It can only call seven backend functions — `get_student_books`, `get_book_details`, `check_renewal_eligibility`, `search_books`, `get_student_fines`, `get_library_rules`, `get_recommendations` — defined in `ai/tools/toolDefinitions.js` and implemented in `backend/services/aiTools.js`, each hard-scoped to the logged-in student's own `studentId`. The system prompt (`ai/prompts/systemPrompt.js`) explicitly forbids inventing data, running SQL, performing a renewal, or discussing another student's records.

**Two modes**, chosen automatically by `backend/services/aiService.js`:

- **Full AI mode** — set `AI_PROVIDER=openai` or `AI_PROVIDER=gemini` and a real `AI_API_KEY`. The assistant calls the provider's API with function-calling enabled, executes whichever of the seven tools the model asks for, feeds the result back, and returns the model's natural-language reply.
- **Basic mode** — if no API key is configured, the assistant runs a small deterministic keyword router (`runBasicMode` in `aiService.js`) that calls the *same* real tool functions and returns a templated, data-grounded reply, clearly labeled as basic mode in its response. It's less conversational, but it never invents anything — every fact it states still came from the database. This means the whole app, including the required demo flow, works out of the box with zero API key.

Provider model names change fairly often — `AI_MODEL` defaults to `gpt-4.1-mini` (OpenAI) or `gemini-2.5-flash` (Gemini) if left blank, but check [platform.openai.com/docs/models](https://platform.openai.com/docs/models) or [ai.google.dev](https://ai.google.dev) for the current recommended small model with function-calling support, and set `AI_MODEL` explicitly if you want to pin one.

## 8. Security

- Every SQL query is a parameterized `pool.execute()` call — no string concatenation, anywhere (see any file in `backend/models/`).
- Passwords are hashed with bcrypt; plaintext passwords are never stored or logged.
- JWT-based auth with role middleware (`backend/middleware/auth.js`) — student and admin routes are hard-separated (`requireStudent` / `requireAdmin`); a student token can never reach an admin endpoint, and this is enforced centrally, not per-controller.
- Sensitive endpoints (login, register, OTP requests, AI chat) are rate-limited.
- **The AI can suggest a renewal but cannot perform one.** Every renewal — whether triggered from the student scan flow, the AI assistant, or the admin panel — goes through `renewalService.renewBook()`, which re-checks eligibility server-side inside a database transaction (`SELECT ... FOR UPDATE`), regardless of what any client claims. See `backend/services/renewalRules.js` for the actual rule logic and `backend/services/renewalRules.test.js` for its test coverage.
- QR codes encode only a non-sensitive book identifier (`BOOK_ID=BK-1025`) — never student data.
- College-domain email restriction on registration, plus a real email-verification OTP step (not just a domain-suffix check).
- An append-only audit log (`audit_logs` table, visible at Admin → Audit Log) records logins, book/student changes, issues, returns, renewals, and fine updates.

## 9. How to Run

```bash
npm install
cp .env.example .env      # fill in your DB credentials at minimum
mysql -u root -p < database/schema.sql
npm run seed
npm start                 # or: npm run dev  (nodemon, auto-reload)
```

The backend runs at `http://localhost:4000` by default (`PORT` in `.env`). Since `server.js` also serves the `frontend/` folder as static files, **open `http://localhost:4000` in your browser and the whole app — API and UI — is right there on one URL.** (Opening `frontend/index.html` directly by double-clicking it still works too — `frontend/js/api.js` detects that and falls back to `http://localhost:4000` for API calls.)

## 9a. Production Readiness Checklist

This repository is configured to run as one Node/Express service: the backend serves the API and the `frontend/` directory from the same public URL. Before deploying:

1. Provision MySQL 8+ and run `database/schema.sql` once.
2. Set `NODE_ENV=production`.
3. Set a random `JWT_SECRET` (32+ characters).
4. Set the real `COLLEGE_EMAIL_DOMAIN`.
5. Set the database variables supplied by your MySQL provider.
6. Set `APP_URL` to the final HTTPS URL.
7. Set `AI_PROVIDER`/`AI_API_KEY` if you want full AI chat; otherwise use `AI_PROVIDER=none`.
8. Configure SMTP (`MAIL_*`) if production email verification/password reset is required.
9. The app exposes `GET /api/health` for the hosting platform's health check.
10. Book covers and generated QR PNGs are stored on the server filesystem. On hosts with ephemeral disks, those files can disappear after redeploy/restart; use a persistent volume or move uploads to object storage before treating this as a production library system.

## 9b. Deploying It (Getting a Real URL)

Running locally is enough for development and grading on your own machine, but if you want a real `https://...` link — to show a professor without them installing anything, or to open from your phone — you need to put the Node process and the MySQL database somewhere that stays running. A static host (Netlify, GitHub Pages, Claude's artifact links, etc.) **cannot** do this: those only serve files to a browser, and this app needs a live server process plus a live database behind it.

**Recommended: Railway** (railway.app) — deploys Node and provisions MySQL in the same project with the least setup. As of 2026 it's not free forever: new accounts get a one-time trial credit (a card is required to start it, but nothing is charged during the trial), then it's roughly $5/month if you keep the project running. For a class project that's usually fine — you can also delete the project when you're done demoing it.

1. **Push this project to a GitHub repo** (Railway deploys from GitHub, or via its CLI without GitHub — see step 2 alternative).
2. At [railway.app](https://railway.app), **New Project → Deploy from GitHub repo**, pick your repo.
   - *No GitHub?* Install the Railway CLI (`npm i -g @railway/cli`), run `railway login`, then from this project's folder run `railway init` and `railway up` — deploys straight from your machine.
3. In the same Railway project, click **+ New → Database → Add MySQL**. Railway provisions it and exposes connection variables automatically (`MYSQLHOST`, `MYSQLPORT`, `MYSQLUSER`, `MYSQLPASSWORD`, `MYSQLDATABASE`).
4. Click into your **app service → Variables**, and add:
   ```
   DB_HOST=${{MySQL.MYSQLHOST}}
   DB_PORT=${{MySQL.MYSQLPORT}}
   DB_USER=${{MySQL.MYSQLUSER}}
   DB_PASSWORD=${{MySQL.MYSQLPASSWORD}}
   DB_NAME=${{MySQL.MYSQLDATABASE}}
   JWT_SECRET=<paste output of: openssl rand -hex 32>
   COLLEGE_EMAIL_DOMAIN=@college-domain.ac.in
   AI_PROVIDER=none
   NODE_ENV=production
   ```
   (Railway's `${{ServiceName.VAR}}` syntax pulls the value live from the MySQL service — you don't need to copy/paste the actual password.)
5. **Load the schema** into the new database. Easiest: Railway's dashboard → your MySQL service → **Data** tab has a query console — paste the entire contents of `database/schema.sql` and run it. (Or, with the Railway CLI: `railway connect mysql < database/schema.sql`.)
6. **Seed demo data**, run from your own machine so it uses your local `npm install`, but targeting the remote database: `railway run npm run seed` (the CLI injects Railway's environment variables for that one command).
7. Railway builds and starts the app automatically (`npm start`, detected from `package.json`). Once the deploy finishes, click **Settings → Networking → Generate Domain** to get your public URL, e.g. `https://smartlib-ai-production.up.railway.app`.
8. Open that URL — frontend and API are both served from it, so there's nothing else to configure.

**Free alternative (more setup, no card required):** deploy the app itself to **Render**'s free web service tier (render.com → New → Web Service → connect your repo; build command `npm install`, start command `npm start`), and get a free MySQL database separately from **Aiven** (aiven.io free tier) or **db4free.net**. Set the same environment variables as above (`DB_HOST`, `DB_USER`, etc.) using whatever that provider gives you, then run steps 5–6 the same way against that database. Render's free tier spins the app down after inactivity, so the first request after a while takes a few extra seconds to wake up — fine for a demo, not for production.

## 10. How to Create an Admin

`npm run seed` creates one for you: **admin@smartlib.ai / Admin@123**.

To add another admin manually, insert directly into the database (there's deliberately no public "become an admin" endpoint):

```sql
-- 1. Hash a password with bcrypt (e.g. via `node -e "console.log(require('bcryptjs').hashSync('YourPassword123', 10))"`)
INSERT INTO users (name, email, password_hash, role, status, email_verified)
VALUES ('Your Name', 'you@smartlib.ai', '<bcrypt hash>', 'admin', 'active', 1);
INSERT INTO admins (user_id, designation) VALUES (LAST_INSERT_ID(), 'Librarian');
```

## 11. How to Add Books & Generate QR Codes

Log in as an admin → **Books** → **Add Book**. A unique `book_id` (e.g. `BK-1013`) and its QR code are generated automatically the moment the book is created — no separate step. From the book list, the QR icon opens a printable card with **Download** and **Print** buttons.

## 12. How to Test QR Renewal

You don't need a real QR-printing setup to test the full flow:

1. Log in as `student1@college-domain.ac.in` / `Student@123` (seeded with 3 books, including one due soon).
2. Go to **Scan & Renew**. If your browser/device has no camera or denies permission, use **Enter Book ID manually** — the seed script prints each demo book's ID, or check the `books` table / the QR download in the admin panel for the exact `BK-####` code.
3. Enter the ID for "Database Management Systems" — you'll see the same eligibility check and renewal confirmation screen a real scan would produce, because manual entry and camera scanning both call the identical `POST /api/books/scan` endpoint.

To test a **rejected** renewal, log in as `student2@college-domain.ac.in` / `Student@123` (seeded with an overdue book) and try renewing their other active book — you should see "Please return your overdue book before requesting another renewal."

## 13. Demo Accounts (from `npm run seed`)

| Role | Email | Password | State |
|---|---|---|---|
| Admin | admin@smartlib.ai | Admin@123 | — |
| Student | student1@college-domain.ac.in | Student@123 | 3 books issued, 1 due soon, ₹0 fine |
| Student | student2@college-domain.ac.in | Student@123 | 1 active, 1 overdue, ₹25 unpaid fine |
| Student | student3@college-domain.ac.in | Student@123 | No books, 1 active reservation |

## 14. Implementation Notes & Reasonable Simplifications

Documented here rather than left silent, per the brief's instruction to make reasonable decisions rather than leave gaps:

- **No ORM** — raw parameterized `mysql2` queries throughout, for transparency (see §3).
- **Cover images** are optional and uploaded separately after a book is created (`PUT /api/books/:id/cover`), rather than bundled into the creation form — keeps the "add book" flow to plain JSON instead of mixing in multipart form data.
- **Issue/Return** are combined into one admin page (Circulation) with tabs, since they share the same scanner component and are performed back-to-back at a real library desk.
- **AI "Renew Now" button**: the spec describes the AI response including an inline renew button. In this build, the AI assistant is a text chat, and renewal is performed from the Scan & Renew screen (which the assistant will point you to) — this keeps the actual renewal transaction on the one screen that also re-verifies the physical/QR identification step, and avoids the AI's chat UI needing to carry transactional state.
- **Email delivery**: without `MAIL_*` configured, OTP codes are logged to the server console and echoed back in the API response only when `NODE_ENV=development` — clearly labeled as dev mode, never silently pretending an email was sent.

## 15. Future Improvements

- Push notifications (the in-app notification center is real; browser/mobile push is not wired up)
- Bulk book import via CSV
- Self-service password change from the profile page
- Admin ability to edit its own profile
- A "return by mail" flow for distance-learning students
