# SmartLib AI — Deployment Guide

## Recommended architecture

Deploy the existing Express app as **one web service**. It serves both:

- `/api/*` — Node/Express API
- `/` and `/student/*`, `/admin/*` — static frontend

Use a managed **MySQL 8+** database.

## 1. Create the database

Run `database/schema.sql` once against a fresh MySQL database.

> The schema contains `DROP TABLE` statements, so treat it as an initial/fresh-database script, not a migration script for an existing production database.

## 2. Production environment variables

Set these in the hosting provider's secret/environment-variable UI:

```text
NODE_ENV=production
PORT=<provided by host, if required>
APP_URL=https://YOUR_PUBLIC_DOMAIN
FRONTEND_URL=

DB_HOST=<mysql host>
DB_PORT=3306
DB_NAME=<mysql database>
DB_USER=<mysql user>
DB_PASSWORD=<mysql password>

JWT_SECRET=<random secret, 32+ characters>
JWT_EXPIRES_IN=7d
BCRYPT_SALT_ROUNDS=10

COLLEGE_EMAIL_DOMAIN=<real college email domain>

AI_PROVIDER=none
AI_API_KEY=
AI_MODEL=

MAIL_HOST=<smtp host>
MAIL_PORT=587
MAIL_USERNAME=<smtp username>
MAIL_PASSWORD=<smtp password>
MAIL_FROM=SmartLib AI <no-reply@your-domain>
```

For full AI chat, change `AI_PROVIDER` to `openai` or `gemini` and provide the corresponding API key.

If the frontend and API are served by this same Express service, leave `FRONTEND_URL` empty. If you host the frontend separately, set it to the frontend origin(s), comma-separated.

## 3. Railway deployment

1. Push this folder to GitHub.
2. Create a Railway project and deploy the GitHub repository as a service.
3. Add a Railway MySQL service to the same project.
4. Map the MySQL service variables to the app service:
   - `DB_HOST` → MySQL `MYSQLHOST`
   - `DB_PORT` → MySQL `MYSQLPORT`
   - `DB_USER` → MySQL `MYSQLUSER`
   - `DB_PASSWORD` → MySQL `MYSQLPASSWORD`
   - `DB_NAME` → MySQL `MYSQLDATABASE`
5. Add the remaining production variables above.
6. Deploy.
7. Configure the Railway healthcheck path as `/api/health`.
8. Generate the public domain and then set `APP_URL` to that HTTPS URL and redeploy.
9. Open `https://YOUR_PUBLIC_DOMAIN/`.

The project already has `npm start`, so no custom start command is normally needed.

## 4. Load demo data

For a class/demo deployment, after the schema is loaded:

```bash
railway run npm run seed
```

The seed script intentionally clears existing application data. In production it is blocked unless you explicitly set:

```text
ALLOW_DESTRUCTIVE_SEED=true
```

Do not enable that variable for a real library database unless you intentionally want to reset all application data.

## 5. Verify deployment

Check:

```text
GET /api/health
```

Expected response contains:

```json
{"success":true,"data":{"status":"ok"}}
```

Then verify:

- Register/login
- Student dashboard
- Admin dashboard
- Book search
- Book issue/return/renewal
- QR generation/scanning
- Fine calculation
- AI assistant (if configured)
- Email verification/password reset (if SMTP is configured)

## Important: uploaded files

Book covers and generated QR images are currently stored under `/uploads` on the application filesystem. Some cloud hosts use ephemeral filesystems, so those files may disappear after a restart/redeploy. For a real production system, use a persistent volume or object storage for uploads.
