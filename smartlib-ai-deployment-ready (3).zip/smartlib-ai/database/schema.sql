-- =====================================================================
-- SmartLib AI — Database Schema (MySQL 8.0+)
-- "Your Library, Anywhere."
-- =====================================================================
-- Run:  mysql -u root -p < database/schema.sql
-- This creates the database and all tables. Run seed data separately
-- with `npm run seed` (backend/scripts/seed.js) after this.
-- =====================================================================

CREATE DATABASE IF NOT EXISTS smartlib_ai
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE smartlib_ai;

SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- users: shared login table for students and admins (role-based)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS users;
CREATE TABLE users (
  id                INT AUTO_INCREMENT PRIMARY KEY,
  name              VARCHAR(150) NOT NULL,
  email             VARCHAR(190) NOT NULL,
  password_hash     VARCHAR(255) NOT NULL,
  role              ENUM('student', 'admin') NOT NULL DEFAULT 'student',
  status            ENUM('pending', 'active', 'blocked', 'deactivated') NOT NULL DEFAULT 'pending',
  email_verified    TINYINT(1) NOT NULL DEFAULT 0,
  created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_users_email (email),
  INDEX idx_users_role (role),
  INDEX idx_users_status (status)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- students: extra profile fields for role='student' users
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS students;
CREATE TABLE students (
  id                INT AUTO_INCREMENT PRIMARY KEY,
  user_id           INT NOT NULL,
  student_id        VARCHAR(50) NOT NULL,
  course            VARCHAR(100) DEFAULT NULL,
  semester          VARCHAR(20) DEFAULT NULL,
  department        VARCHAR(100) DEFAULT NULL,
  phone             VARCHAR(20) DEFAULT NULL,
  created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_students_user (user_id),
  UNIQUE KEY uq_students_student_id (student_id),
  CONSTRAINT fk_students_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- admins: extra profile fields for role='admin' users
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS admins;
CREATE TABLE admins (
  id                INT AUTO_INCREMENT PRIMARY KEY,
  user_id           INT NOT NULL,
  designation       VARCHAR(100) DEFAULT 'Librarian',
  created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_admins_user (user_id),
  CONSTRAINT fk_admins_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- email_verifications: OTP / token records for email verification
--                       and forgot-password flows
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS email_verifications;
CREATE TABLE email_verifications (
  id                INT AUTO_INCREMENT PRIMARY KEY,
  user_id           INT NOT NULL,
  code_hash         VARCHAR(255) NOT NULL,
  purpose           ENUM('verify_email', 'reset_password') NOT NULL DEFAULT 'verify_email',
  expires_at        DATETIME NOT NULL,
  consumed_at       DATETIME DEFAULT NULL,
  created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_ev_user (user_id),
  CONSTRAINT fk_ev_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- categories
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS categories;
CREATE TABLE categories (
  id                INT AUTO_INCREMENT PRIMARY KEY,
  name              VARCHAR(100) NOT NULL,
  UNIQUE KEY uq_category_name (name)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- books
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS books;
CREATE TABLE books (
  id                    INT AUTO_INCREMENT PRIMARY KEY,
  book_id               VARCHAR(20) NOT NULL,          -- e.g. BK-1025 (encoded in QR)
  isbn                  VARCHAR(20) DEFAULT NULL,
  title                 VARCHAR(255) NOT NULL,
  author                VARCHAR(255) NOT NULL,
  publisher             VARCHAR(150) DEFAULT NULL,
  edition               VARCHAR(50) DEFAULT NULL,
  category_id           INT DEFAULT NULL,
  description           TEXT,
  cover_image           VARCHAR(255) DEFAULT NULL,
  qr_image              VARCHAR(255) DEFAULT NULL,
  shelf_number          VARCHAR(50) DEFAULT NULL,
  quantity              INT NOT NULL DEFAULT 1,
  available_quantity    INT NOT NULL DEFAULT 1,
  is_active             TINYINT(1) NOT NULL DEFAULT 1,
  created_at            DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at            DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_books_book_id (book_id),
  INDEX idx_books_title (title),
  INDEX idx_books_author (author),
  INDEX idx_books_isbn (isbn),
  INDEX idx_books_category (category_id),
  CONSTRAINT fk_books_category FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- issues: one row per book issued to a student
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS issues;
CREATE TABLE issues (
  id                INT AUTO_INCREMENT PRIMARY KEY,
  student_id        INT NOT NULL,
  book_id           INT NOT NULL,
  issue_date        DATE NOT NULL,
  due_date          DATE NOT NULL,
  returned_date     DATE DEFAULT NULL,
  renewal_count     INT NOT NULL DEFAULT 0,
  status            ENUM('active', 'returned', 'overdue') NOT NULL DEFAULT 'active',
  issued_by         INT DEFAULT NULL,                  -- admin user id, null if self-service
  returned_to       INT DEFAULT NULL,
  created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_issues_student (student_id),
  INDEX idx_issues_book (book_id),
  INDEX idx_issues_status (status),
  CONSTRAINT fk_issues_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  CONSTRAINT fk_issues_book FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,
  CONSTRAINT fk_issues_issued_by FOREIGN KEY (issued_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_issues_returned_to FOREIGN KEY (returned_to) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- renewals: history log, one row per renewal performed on an issue
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS renewals;
CREATE TABLE renewals (
  id                  INT AUTO_INCREMENT PRIMARY KEY,
  issue_id            INT NOT NULL,
  student_id          INT NOT NULL,
  book_id             INT NOT NULL,
  previous_due_date   DATE NOT NULL,
  new_due_date        DATE NOT NULL,
  renewal_number      INT NOT NULL,
  method              ENUM('self_service', 'admin') NOT NULL DEFAULT 'self_service',
  status              ENUM('approved', 'rejected') NOT NULL DEFAULT 'approved',
  rejection_reason    VARCHAR(255) DEFAULT NULL,
  performed_by        INT DEFAULT NULL,                -- admin user id if method=admin
  created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_renewals_issue (issue_id),
  INDEX idx_renewals_student (student_id),
  CONSTRAINT fk_renewals_issue FOREIGN KEY (issue_id) REFERENCES issues(id) ON DELETE CASCADE,
  CONSTRAINT fk_renewals_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  CONSTRAINT fk_renewals_book FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- fines
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS fines;
CREATE TABLE fines (
  id                INT AUTO_INCREMENT PRIMARY KEY,
  student_id        INT NOT NULL,
  issue_id          INT NOT NULL,
  amount            DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  reason            VARCHAR(255) NOT NULL DEFAULT 'Overdue return',
  status            ENUM('unpaid', 'paid', 'waived') NOT NULL DEFAULT 'unpaid',
  created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  paid_at           DATETIME DEFAULT NULL,
  INDEX idx_fines_student (student_id),
  INDEX idx_fines_status (status),
  CONSTRAINT fk_fines_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  CONSTRAINT fk_fines_issue FOREIGN KEY (issue_id) REFERENCES issues(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- reservations
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS reservations;
CREATE TABLE reservations (
  id                INT AUTO_INCREMENT PRIMARY KEY,
  student_id        INT NOT NULL,
  book_id           INT NOT NULL,
  status            ENUM('active', 'fulfilled', 'cancelled', 'expired') NOT NULL DEFAULT 'active',
  reserved_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  notified_at       DATETIME DEFAULT NULL,
  fulfilled_at      DATETIME DEFAULT NULL,
  UNIQUE KEY uq_active_reservation (student_id, book_id, status),
  INDEX idx_reservations_book (book_id),
  CONSTRAINT fk_reservations_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  CONSTRAINT fk_reservations_book FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- notifications
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS notifications;
CREATE TABLE notifications (
  id                INT AUTO_INCREMENT PRIMARY KEY,
  user_id           INT NOT NULL,
  type              VARCHAR(50) NOT NULL DEFAULT 'general', -- due_soon | overdue | renewed | fine | reservation | system
  title             VARCHAR(150) NOT NULL,
  message           VARCHAR(500) NOT NULL,
  is_read           TINYINT(1) NOT NULL DEFAULT 0,
  created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_notifications_user (user_id, is_read),
  CONSTRAINT fk_notifications_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- library_settings: single-row configurable rules table (key/value)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS library_settings;
CREATE TABLE library_settings (
  setting_key       VARCHAR(80) NOT NULL PRIMARY KEY,
  setting_value     VARCHAR(255) NOT NULL,
  description       VARCHAR(255) DEFAULT NULL,
  updated_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- ai_conversations / ai_messages
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS ai_messages;
DROP TABLE IF EXISTS ai_conversations;
CREATE TABLE ai_conversations (
  id                INT AUTO_INCREMENT PRIMARY KEY,
  student_id        INT NOT NULL,
  title             VARCHAR(150) DEFAULT 'New conversation',
  created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_aiconv_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE ai_messages (
  id                INT AUTO_INCREMENT PRIMARY KEY,
  conversation_id   INT NOT NULL,
  role              ENUM('user', 'assistant', 'tool') NOT NULL,
  content           TEXT NOT NULL,
  tool_calls        JSON DEFAULT NULL,
  created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_aimsg_conv (conversation_id),
  CONSTRAINT fk_aimsg_conv FOREIGN KEY (conversation_id) REFERENCES ai_conversations(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- audit_logs
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS audit_logs;
CREATE TABLE audit_logs (
  id                INT AUTO_INCREMENT PRIMARY KEY,
  user_id           INT DEFAULT NULL,
  action            VARCHAR(100) NOT NULL,
  target             VARCHAR(150) DEFAULT NULL,
  details           JSON DEFAULT NULL,
  created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_audit_user (user_id),
  INDEX idx_audit_action (action),
  CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

SET FOREIGN_KEY_CHECKS = 1;
