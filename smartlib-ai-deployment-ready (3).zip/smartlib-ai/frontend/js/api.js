// frontend/js/api.js
//
// Talks to the SmartLib AI backend (backend/server.js).
// Resolution order:
//   1. window.SMARTLIB_API_BASE, if you set it explicitly (e.g. pointing the
//      frontend at a backend running somewhere other than the same origin).
//   2. If this page was opened as a local file (file://), fall back to
//      http://localhost:4000 — the usual "open index.html directly" flow.
//   3. Otherwise, use the current origin. This is what makes deployment
//      simple: since server.js also serves the frontend as static files,
//      a deployed backend and its frontend share one URL automatically.
const API_BASE = (
  window.SMARTLIB_API_BASE !== undefined
    ? window.SMARTLIB_API_BASE
    : (location.protocol === 'file:' ? 'http://localhost:4000' : location.origin)
) + '/api';

const Auth = {
  TOKEN_KEY: 'smartlib_token',
  USER_KEY: 'smartlib_user',

  getToken() { return localStorage.getItem(this.TOKEN_KEY); },
  getUser() {
    try { return JSON.parse(localStorage.getItem(this.USER_KEY) || 'null'); }
    catch { return null; }
  },
  setSession(token, user) {
    localStorage.setItem(this.TOKEN_KEY, token);
    localStorage.setItem(this.USER_KEY, JSON.stringify(user));
  },
  clearSession() {
    localStorage.removeItem(this.TOKEN_KEY);
    localStorage.removeItem(this.USER_KEY);
  },
  isLoggedIn() { return Boolean(this.getToken()); },
  logout() {
    this.clearSession();
    window.location.href = '/login.html';
  },
};

class ApiError extends Error {
  constructor(message, code, status) {
    super(message);
    this.code = code;
    this.status = status;
  }
}

async function apiRequest(method, path, { body, params, isFormData } = {}) {
  let url = API_BASE + path;
  if (params) {
    const qs = new URLSearchParams(
      Object.fromEntries(Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== ''))
    ).toString();
    if (qs) url += '?' + qs;
  }

  const headers = {};
  const token = Auth.getToken();
  if (token) headers.Authorization = `Bearer ${token}`;

  let fetchBody;
  if (isFormData) {
    fetchBody = body; // FormData sets its own Content-Type boundary
  } else if (body !== undefined) {
    headers['Content-Type'] = 'application/json';
    fetchBody = JSON.stringify(body);
  }

  let res;
  try {
    res = await fetch(url, { method, headers, body: fetchBody });
  } catch (err) {
    throw new ApiError('Could not reach the SmartLib AI server. Is the backend running?', 'NETWORK_ERROR', 0);
  }

  let json = null;
  try { json = await res.json(); } catch { /* no body */ }

  if (!res.ok) {
    const message = (json && json.error && json.error.message) || `Request failed (${res.status}).`;
    const code = (json && json.error && json.error.code) || 'ERROR';
    if (res.status === 401 && code !== 'INVALID_CREDENTIALS') {
      // Session expired/invalid — clear it and send the person to log in.
      Auth.clearSession();
      if (!location.pathname.endsWith('/login.html')) {
        sessionStorage.setItem('smartlib_redirect_reason', 'Your session expired. Please log in again.');
        window.location.href = '/login.html';
      }
    }
    throw new ApiError(message, code, res.status);
  }

  return json ? json.data : null;
}

const Api = {
  get: (path, params) => apiRequest('GET', path, { params }),
  post: (path, body) => apiRequest('POST', path, { body }),
  put: (path, body) => apiRequest('PUT', path, { body }),
  del: (path) => apiRequest('DELETE', path),
  upload: (path, formData) => apiRequest('PUT', path, { body: formData, isFormData: true }),
};
