// frontend/js/ui.js

function ensureToastRegion() {
  let region = document.getElementById('toast-region');
  if (!region) {
    region = document.createElement('div');
    region.id = 'toast-region';
    document.body.appendChild(region);
  }
  return region;
}

function toast(message, type = 'default', duration = 4200) {
  const region = ensureToastRegion();
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = message;
  region.appendChild(el);
  setTimeout(() => el.remove(), duration);
}

function toastError(err) {
  const message = err && err.message ? err.message : 'Something went wrong. Please try again.';
  toast(message, 'error', 5200);
}

function formatDate(dateStr) {
  if (!dateStr) return '\u2014';
  const d = new Date(dateStr + 'T00:00:00');
  if (Number.isNaN(d.getTime())) return dateStr;
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

function formatDateTime(dateStr) {
  if (!dateStr) return '\u2014';
  const d = new Date(dateStr);
  if (Number.isNaN(d.getTime())) return dateStr;
  return d.toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function initials(name) {
  if (!name) return '?';
  return name.trim().split(/\s+/).slice(0, 2).map((w) => w[0]?.toUpperCase() || '').join('');
}

function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function el(html) {
  const t = document.createElement('template');
  t.innerHTML = html.trim();
  return t.content.firstElementChild;
}

function statusPill(status) {
  const map = {
    active: { cls: 'pill-accent', label: 'Active' },
    due_soon: { cls: 'pill-warn', label: 'Due soon' },
    overdue: { cls: 'pill-danger', label: 'Overdue' },
    returned: { cls: 'pill-neutral', label: 'Returned' },
    renewable: { cls: 'pill-accent', label: 'Renewable' },
    reserved: { cls: 'pill-neutral', label: 'Reserved' },
    limit_reached: { cls: 'pill-neutral', label: 'Renewal limit reached' },
    unpaid: { cls: 'pill-danger', label: 'Unpaid' },
    paid: { cls: 'pill-accent', label: 'Paid' },
    waived: { cls: 'pill-neutral', label: 'Waived' },
    fulfilled: { cls: 'pill-accent', label: 'Fulfilled' },
    cancelled: { cls: 'pill-neutral', label: 'Cancelled' },
    expired: { cls: 'pill-neutral', label: 'Expired' },
  };
  const m = map[status] || { cls: 'pill-neutral', label: status };
  return `<span class="pill ${m.cls}"><span class="pill-dot"></span>${m.label}</span>`;
}

function openModal(innerHtml, { onClose } = {}) {
  const overlay = el(`<div class="modal-overlay"><div class="modal">${innerHtml}</div></div>`);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
  document.addEventListener('keydown', escHandler);
  function escHandler(e) { if (e.key === 'Escape') close(); }
  function close() {
    overlay.remove();
    document.removeEventListener('keydown', escHandler);
    if (onClose) onClose();
  }
  document.body.appendChild(overlay);
  return { overlay, close };
}

function loadingRow(text = 'Loading\u2026') {
  return `<div class="loading-row"><div class="spinner"></div><span>${escapeHtml(text)}</span></div>`;
}

function emptyState(icon, title, subtitle = '') {
  return `<div class="empty-state"><div class="ico">${icon}</div><h4>${escapeHtml(title)}</h4>${subtitle ? `<p>${escapeHtml(subtitle)}</p>` : ''}</div>`;
}
