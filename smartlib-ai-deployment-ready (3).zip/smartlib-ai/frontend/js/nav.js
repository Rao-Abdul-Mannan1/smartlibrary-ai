// frontend/js/nav.js

const STUDENT_NAV = [
  { key: 'dashboard', label: 'Dashboard', href: 'dashboard.html', icon: 'home' },
  { key: 'my-books', label: 'My Books', href: 'my-books.html', icon: 'book' },
  { key: 'scan-renew', label: 'Scan & Renew', href: 'scan-renew.html', icon: 'scan' },
  { key: 'search', label: 'Search Books', href: 'search.html', icon: 'search' },
  { key: 'ai-assistant', label: 'AI Assistant', href: 'ai-assistant.html', icon: 'sparkle' },
  { key: 'renewals', label: 'Renewal History', href: 'renewals.html', icon: 'refresh' },
  { key: 'reservations', label: 'Reservations', href: 'reservations.html', icon: 'bookmark' },
  { key: 'fines', label: 'Fines', href: 'fines.html', icon: 'receipt' },
  { key: 'notifications', label: 'Notifications', href: 'notifications.html', icon: 'bell' },
  { key: 'rules', label: 'Library Rules', href: 'rules.html', icon: 'info' },
  { key: 'profile', label: 'Profile', href: 'profile.html', icon: 'user' },
];

// Bottom nav on mobile only has room for ~5 items.
const STUDENT_BOTTOM_NAV = ['dashboard', 'my-books', 'scan-renew', 'ai-assistant', 'notifications'];

const ADMIN_NAV = [
  { key: 'dashboard', label: 'Dashboard', href: 'dashboard.html', icon: 'home' },
  { key: 'books', label: 'Books', href: 'books.html', icon: 'book' },
  { key: 'circulation', label: 'Issue / Return', href: 'circulation.html', icon: 'swap' },
  { key: 'students', label: 'Students', href: 'students.html', icon: 'users' },
  { key: 'renewals', label: 'Renewals', href: 'renewals.html', icon: 'refresh' },
  { key: 'reservations', label: 'Reservations', href: 'reservations.html', icon: 'bookmark' },
  { key: 'fines', label: 'Fines', href: 'fines.html', icon: 'receipt' },
  { key: 'reports', label: 'Reports', href: 'reports.html', icon: 'chart' },
  { key: 'settings', label: 'Library Settings', href: 'settings.html', icon: 'settings' },
  { key: 'audit-log', label: 'Audit Log', href: 'audit-log.html', icon: 'list' },
  { key: 'profile', label: 'Profile', href: 'profile.html', icon: 'user' },
];
const ADMIN_BOTTOM_NAV = ['dashboard', 'books', 'circulation', 'students', 'reports'];

// Redirects away if not logged in / wrong role. Call at the top of every protected page.
function requireAuth(role) {
  const user = Auth.getUser();
  if (!Auth.isLoggedIn() || !user) {
    window.location.href = rootPath() + 'login.html';
    return null;
  }
  if (role && user.role !== role) {
    window.location.href = rootPath() + (user.role === 'admin' ? 'admin/dashboard.html' : 'student/dashboard.html');
    return null;
  }
  return user;
}

function rootPath() {
  // Pages live at root, /student/, or /admin/ — one level deep at most.
  const parts = window.location.pathname.split('/').filter(Boolean);
  const inSubfolder = parts.length >= 2 && (parts[parts.length - 2] === 'student' || parts[parts.length - 2] === 'admin');
  return inSubfolder ? '../' : '';
}

async function renderShell(activeKey) {
  const user = Auth.getUser();
  if (!user) return;
  const isAdmin = user.role === 'admin';
  const navItems = isAdmin ? ADMIN_NAV : STUDENT_NAV;
  const bottomKeys = isAdmin ? ADMIN_BOTTOM_NAV : STUDENT_BOTTOM_NAV;

  const sidebar = document.getElementById('sidebar');
  if (sidebar) {
    sidebar.innerHTML = `
      <div class="brand"><span class="brand-mark">${icon('book', 18)}</span>SmartLib AI</div>
      ${navItems.map((item) => `
        <a class="nav-link ${item.key === activeKey ? 'active' : ''}" href="${item.href}">
          <span class="ico">${icon(item.icon, 18)}</span>${item.label}
        </a>`).join('')}
      <div class="sidebar-footer">
        <a class="nav-link" href="#" id="logout-link"><span class="ico">${icon('logout', 18)}</span>Log out</a>
      </div>
    `;
    document.getElementById('logout-link').addEventListener('click', (e) => { e.preventDefault(); Auth.logout(); });
  }

  const bottomNav = document.getElementById('bottom-nav');
  if (bottomNav) {
    bottomNav.innerHTML = navItems
      .filter((item) => bottomKeys.includes(item.key))
      .map((item) => `
        <a href="${item.href}" class="${item.key === activeKey ? 'active' : ''}">
          <span class="ico">${icon(item.icon, 20)}</span>${item.label.split(' ')[0]}
        </a>`).join('');
  }

  const topbar = document.getElementById('topbar');
  if (topbar) {
    topbar.innerHTML = `
      <button class="icon-btn" id="mobile-menu-btn" style="display:none">${icon('menu', 18)}</button>
      <div class="header-actions" style="margin-left:0">
        <h3 style="margin:0">${navItems.find((i) => i.key === activeKey)?.label || ''}</h3>
      </div>
      <div class="header-actions">
        <a class="icon-btn" href="${isAdmin ? '' : ''}notifications.html" title="Notifications" style="position:relative" id="notif-bell">
          ${icon('bell', 18)}
          <span class="badge-dot" id="notif-badge" style="display:none"></span>
        </a>
        <div class="avatar" title="${escapeHtml(user.name)}">${initials(user.name)}</div>
      </div>
    `;
    if (isAdmin) {
      const bell = document.getElementById('notif-bell');
      if (bell) bell.style.display = 'none'; // admin nav doesn't have a dedicated notifications page yet
    } else {
      refreshNotifBadge();
    }
  }
}

async function refreshNotifBadge() {
  try {
    const data = await Api.get('/notifications', { limit: 1 });
    const badge = document.getElementById('notif-badge');
    if (badge) badge.style.display = data.unread > 0 ? 'block' : 'none';
  } catch { /* non-critical */ }
}
