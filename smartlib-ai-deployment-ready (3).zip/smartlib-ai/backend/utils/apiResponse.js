// backend/utils/apiResponse.js
// Small helpers so every endpoint returns a consistent JSON envelope:
//   { success: true,  data: ... }
//   { success: false, error: { message, code } }

class ApiError extends Error {
  constructor(statusCode, message, code = 'ERROR') {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
  }
}

function ok(res, data, statusCode = 200) {
  return res.status(statusCode).json({ success: true, data });
}

function fail(res, statusCode, message, code = 'ERROR') {
  return res.status(statusCode).json({ success: false, error: { message, code } });
}

module.exports = { ApiError, ok, fail };
