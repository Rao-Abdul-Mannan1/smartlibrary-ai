// backend/utils/validators.js
const env = require('../config/env');

function isValidEmail(email) {
  return typeof email === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// College-domain check. COLLEGE_EMAIL_DOMAIN is configurable via .env,
// e.g. "@college-domain.ac.in". Never hard-coded.
function isCollegeEmail(email) {
  if (!isValidEmail(email)) return false;
  const domain = env.COLLEGE_EMAIL_DOMAIN.toLowerCase();
  return email.toLowerCase().endsWith(domain);
}

// Minimum 8 chars, at least one letter and one number.
function isStrongPassword(pw) {
  return typeof pw === 'string' && pw.length >= 8 && /[A-Za-z]/.test(pw) && /[0-9]/.test(pw);
}

function isNonEmptyString(v, maxLen = 255) {
  return typeof v === 'string' && v.trim().length > 0 && v.length <= maxLen;
}

module.exports = { isValidEmail, isCollegeEmail, isStrongPassword, isNonEmptyString };
