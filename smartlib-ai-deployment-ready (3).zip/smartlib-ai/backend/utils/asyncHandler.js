// backend/utils/asyncHandler.js
// Wraps an async Express route handler so any thrown error / rejected
// promise is forwarded to the error-handling middleware instead of
// crashing the process or hanging the request.
module.exports = function asyncHandler(fn) {
  return function wrapped(req, res, next) {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
};
