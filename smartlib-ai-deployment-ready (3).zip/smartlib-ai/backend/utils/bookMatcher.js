// backend/utils/bookMatcher.js
//
// Students (and the AI's basic-mode fallback) refer to books by common
// shorthand — "DBMS", "OS", "CN" — that won't appear as a literal
// substring of the full title ("Database Management Systems"). This
// module is a small, honest alias table plus a word-overlap matcher,
// not a claim of semantic understanding. Pure functions, no deps —
// see bookMatcher.test.js.

const ABBREVIATIONS = {
  dbms: 'database management systems',
  os: 'operating systems',
  cn: 'computer networks',
  dsa: 'data structures',
  ds: 'data structures',
  ai: 'artificial intelligence',
  ml: 'machine learning',
  coa: 'computer organization',
  cyber: 'cyber security',
  cybersecurity: 'cyber security',
  infosec: 'cyber security',
  webdev: 'web development',
  dbs: 'database management systems',
};

const STOPWORDS = new Set([
  'my', 'the', 'a', 'an', 'is', 'are', 'please', 'book', 'books', 'for',
  'can', 'i', 'renew', 'when', 'due', 'about', 'on', 'find', 'search',
  'recommend', 'suggest', 'learning', 'to', 'of', 'me',
]);

function normalize(str) {
  return (str || '')
    .toLowerCase()
    .replace(/[^a-z0-9 ]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/** Strips filler/stopwords from free text, leaving the likely subject. */
function extractSubject(message) {
  const words = normalize(message).split(' ').filter((w) => w && !STOPWORDS.has(w));
  return words.join(' ').trim() || null;
}

/** True if `query` plausibly refers to `title` (exact, alias, or word-overlap match). */
function titleMatches(query, title) {
  const q = normalize(query);
  const t = normalize(title);
  if (!q || !t) return false;
  if (t.includes(q) || q.includes(t)) return true;

  const expanded = ABBREVIATIONS[q];
  if (expanded && t.includes(expanded)) return true;

  const qWords = q.split(' ').filter((w) => w.length >= 2);
  if (qWords.length && qWords.every((w) => t.includes(w) || (ABBREVIATIONS[w] && t.includes(ABBREVIATIONS[w])))) {
    return true;
  }
  return false;
}

/** Expands a query to a broader search term when it's a known abbreviation, else returns it unchanged. */
function expandForSearch(query) {
  const q = normalize(query);
  return ABBREVIATIONS[q] || query;
}

module.exports = { normalize, extractSubject, titleMatches, expandForSearch, ABBREVIATIONS };
