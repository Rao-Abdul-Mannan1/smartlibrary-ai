// backend/utils/dateUtils.js
// Pure date helpers — no DB, no I/O — so they're trivial to unit test.

function todayISO() {
  return new Date().toISOString().slice(0, 10); // 'YYYY-MM-DD'
}

function addDays(dateStr, days) {
  const d = new Date(dateStr + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

// Whole days between two 'YYYY-MM-DD' strings (b - a). Positive if b is after a.
function daysBetween(aStr, bStr) {
  const a = new Date(aStr + 'T00:00:00Z');
  const b = new Date(bStr + 'T00:00:00Z');
  const MS_PER_DAY = 24 * 60 * 60 * 1000;
  return Math.round((b - a) / MS_PER_DAY);
}

function isPast(dateStr, referenceStr = todayISO()) {
  return daysBetween(referenceStr, dateStr) < 0;
}

function formatDisplay(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr + 'T00:00:00Z');
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', timeZone: 'UTC' });
}

module.exports = { todayISO, addDays, daysBetween, isPast, formatDisplay };
