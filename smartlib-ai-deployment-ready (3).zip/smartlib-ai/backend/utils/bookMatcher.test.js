// backend/utils/bookMatcher.test.js
// Run with: node backend/utils/bookMatcher.test.js
const assert = require('assert');
const { extractSubject, titleMatches, expandForSearch } = require('./bookMatcher');

let passed = 0;
function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  ok - ${name}`);
  } catch (err) {
    console.error(`  FAIL - ${name}\n         ${err.message}`);
    process.exitCode = 1;
  }
}

console.log('bookMatcher');

test('extractSubject strips filler words down to the subject', () => {
  assert.strictEqual(extractSubject('Can I renew my DBMS book?'), 'dbms');
  assert.strictEqual(extractSubject('When is my DBMS book due?'), 'dbms');
  assert.strictEqual(extractSubject('Recommend books for learning programming'), 'programming');
  assert.strictEqual(extractSubject('Find books about cybersecurity'), 'cybersecurity');
});

test('titleMatches: abbreviation "DBMS" matches full title', () => {
  assert.strictEqual(titleMatches('dbms', 'Database Management Systems'), true);
  assert.strictEqual(titleMatches('DBMS', 'Database Management Systems'), true);
});

test('titleMatches: "OS" matches "Operating Systems"', () => {
  assert.strictEqual(titleMatches('os', 'Operating Systems'), true);
});

test('titleMatches: exact substring still matches', () => {
  assert.strictEqual(titleMatches('networks', 'Computer Networks'), true);
});

test('titleMatches: unrelated query does not match', () => {
  assert.strictEqual(titleMatches('cooking', 'Database Management Systems'), false);
});

test('end-to-end: "Can I renew my DBMS book?" resolves to the DBMS title', () => {
  const subject = extractSubject('Can I renew my DBMS book?');
  assert.strictEqual(titleMatches(subject, 'Database Management Systems'), true);
});

test('expandForSearch turns a known abbreviation into a searchable phrase', () => {
  assert.strictEqual(expandForSearch('dbms'), 'database management systems');
  assert.strictEqual(expandForSearch('unknownterm'), 'unknownterm');
});

console.log(`\n${passed} test(s) passed.`);
