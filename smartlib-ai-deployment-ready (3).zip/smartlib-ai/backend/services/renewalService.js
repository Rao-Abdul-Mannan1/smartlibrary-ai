// backend/services/renewalService.js
//
// This is the single source of truth for "can this book be renewed?".
// The AI assistant, the student scan-and-renew flow, and the admin
// renewal-management screen all end up calling `checkEligibility` /
// `renewBook` below — nobody else is allowed to decide eligibility or
// touch the `issues` table directly. See section 9 of the spec:
// "AI must NEVER independently decide whether a renewal is legally/
// technically allowed. The backend is the final authority."

const { pool, withTransaction } = require('../config/db');
const issueModel = require('../models/issueModel');
const renewalModel = require('../models/renewalModel');
const bookModel = require('../models/bookModel');
const fineModel = require('../models/fineModel');
const reservationModel = require('../models/reservationModel');
const notificationModel = require('../models/notificationModel');
const settingsModel = require('../models/settingsModel');
const dateUtils = require('../utils/dateUtils');
const { ApiError } = require('../utils/apiResponse');
const { evaluateEligibility } = require('./renewalRules');

/**
 * Gathers the live facts for one issue and runs them through
 * evaluateEligibility(). Read-only — safe to call as often as needed
 * (e.g. every time the AI assistant is asked "can I renew this?").
 */
async function checkEligibility(issue) {
  const settings = await settingsModel.getAll();
  const maxRenewals = Number(settings.max_renewals_per_book);
  const maxUnpaidFineAllowed = Number(settings.max_unpaid_fine_allowed);

  const [isReservedByOther, studentHasOtherOverdue, unpaidFineTotal] = await Promise.all([
    reservationModel.isReservedByAnotherStudent(issue.book_id, issue.student_id),
    issueModel.hasAnyOverdue(issue.student_id, issue.id),
    fineModel.totalUnpaidByStudent(issue.student_id),
  ]);

  // The issue's own due date counts too — check it directly rather than
  // relying on the (possibly stale) `status` column.
  const isThisOneOverdue = dateUtils.isPast(issue.due_date, dateUtils.todayISO());

  const facts = {
    today: dateUtils.todayISO(),
    dueDate: issue.due_date,
    renewalCount: issue.renewal_count,
    maxRenewals,
    isReservedByOther,
    studentHasOtherOverdue: studentHasOtherOverdue || isThisOneOverdue,
    unpaidFineTotal,
    maxUnpaidFineAllowed,
    accountStatus: issue.account_status || 'active',
    alreadyReturned: issue.status === 'returned',
  };

  const verdict = evaluateEligibility(facts);
  return { ...verdict, renewalsUsed: issue.renewal_count, maxRenewals, facts };
}

/**
 * Performs a renewal inside a DB transaction: re-checks eligibility
 * (never trust a stale client-side check), updates the issue's due
 * date, logs the renewal, and creates a notification. Throws ApiError
 * with a clear message if not eligible.
 */
async function renewBook({ issueId, studentId, method = 'self_service', performedBy = null }) {
  return withTransaction(async (conn) => {
    const [rows] = await conn.execute(
      `SELECT i.*, s.id AS student_row_id, u.status AS account_status, u.id AS user_id
       FROM issues i
       JOIN students s ON s.id = i.student_id
       JOIN users u ON u.id = s.user_id
       WHERE i.id = ? FOR UPDATE`,
      [issueId]
    );
    const issue = rows[0];
    if (!issue) throw new ApiError(404, 'Issue record not found.', 'NOT_FOUND');
    if (issue.student_id !== studentId) {
      throw new ApiError(403, 'This book is not issued to your account.', 'FORBIDDEN');
    }

    const verdict = await checkEligibility(issue);
    if (!verdict.eligible) {
      throw new ApiError(400, verdict.reason, verdict.reasonCode);
    }

    const settings = await settingsModel.getAll();
    const renewalDays = Number(settings.renewal_period_days);
    const newDueDate = dateUtils.addDays(issue.due_date, renewalDays);
    const renewalNumber = issue.renewal_count + 1;

    await issueModel.applyRenewal(conn, issueId, newDueDate);
    await renewalModel.record(conn, {
      issueId,
      studentId: issue.student_id,
      bookId: issue.book_id,
      previousDueDate: issue.due_date,
      newDueDate,
      renewalNumber,
      method,
      performedBy,
    });

    const book = await bookModel.findById(issue.book_id);
    await notificationModel.create(conn, {
      userId: issue.user_id,
      type: 'renewed',
      title: 'Book renewed',
      message: `"${book.title}" has been renewed. New due date: ${dateUtils.formatDisplay(newDueDate)}.`,
    });

    return {
      issueId,
      book: { id: book.id, bookId: book.book_id, title: book.title, author: book.author },
      previousDueDate: issue.due_date,
      newDueDate,
      renewalNumber,
      maxRenewals: Number(settings.max_renewals_per_book),
    };
  });
}

module.exports = { evaluateEligibility, checkEligibility, renewBook };
