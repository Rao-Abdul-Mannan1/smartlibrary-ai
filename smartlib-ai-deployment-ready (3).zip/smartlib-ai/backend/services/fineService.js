// backend/services/fineService.js
const fineModel = require('../models/fineModel');
const { calculateFine } = require('./fineRules');

/**
 * Creates a fine record (inside the given transaction connection) if
 * the return was late. Returns null when there was no overdue amount,
 * so callers don't create pointless ₹0 fine rows.
 */
async function applyFineIfOverdue(conn, { studentId, issueId, dueDate, returnDate, ratePerDay }) {
  const { overdueDays, amount } = calculateFine({ dueDate, returnDate, ratePerDay });
  if (overdueDays <= 0 || amount <= 0) return null;

  const fineId = await fineModel.create(conn, {
    studentId,
    issueId,
    amount,
    reason: `Overdue return — ${overdueDays} day(s) late`,
  });
  return { id: fineId, overdueDays, amount };
}

module.exports = { calculateFine, applyFineIfOverdue };
