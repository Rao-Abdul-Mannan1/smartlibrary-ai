// backend/services/qrService.js
//
// Generates a QR code PNG for a book. The QR encodes ONLY a safe,
// non-sensitive identifier — never student data (see spec section 6):
//   BOOK_ID=BK-1025
//
// The scanner (frontend/js/scanner.js, via the html5-qrcode library)
// reads this string back and calls POST /api/books/scan with it.

const QRCode = require('qrcode');
const path = require('path');
const fs = require('fs');

const QR_DIR = path.join(__dirname, '..', '..', 'uploads', 'qr');

function payloadFor(bookId) {
  return `BOOK_ID=${bookId}`;
}

async function generateForBook(bookId) {
  if (!fs.existsSync(QR_DIR)) fs.mkdirSync(QR_DIR, { recursive: true });
  const fileName = `${bookId}.png`;
  const filePath = path.join(QR_DIR, fileName);
  await QRCode.toFile(filePath, payloadFor(bookId), {
    errorCorrectionLevel: 'M',
    margin: 2,
    width: 400,
  });
  // Path as served by express.static('/uploads', ...) — see server.js
  return `/uploads/qr/${fileName}`;
}

// Parses a scanned string back into a book_id. Accepts either the raw
// "BOOK_ID=BK-1025" payload or a bare "BK-1025" (manual-entry fallback).
function parseScannedPayload(raw) {
  if (!raw || typeof raw !== 'string') return null;
  const trimmed = raw.trim();
  const match = trimmed.match(/^BOOK_ID=(.+)$/i);
  if (match) return match[1].trim();
  if (/^BK-\d+$/i.test(trimmed)) return trimmed.toUpperCase();
  return null;
}

module.exports = { payloadFor, generateForBook, parseScannedPayload };
