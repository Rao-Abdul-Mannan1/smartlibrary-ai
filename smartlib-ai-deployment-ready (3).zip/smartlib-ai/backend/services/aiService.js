// backend/services/aiService.js
//
// Provider-agnostic AI orchestration. Reads AI_PROVIDER / AI_API_KEY /
// AI_MODEL from .env (never hard-coded, never sent to the frontend).
//
// Architecture (see spec sections 9, 42, 43):
//   student message -> system prompt + controlled tools offered to model
//        -> model decides which tool(s) to call -> we execute the REAL,
//           student-scoped function from aiTools.js -> feed the result
//           back to the model -> model writes the final natural-language
//           reply
// The model never touches SQL and never performs a renewal itself.
//
// If no AI_API_KEY is configured, `chat()` runs in "basic mode": a small
// deterministic keyword router that calls the exact same real aiTools
// functions and returns a templated, data-grounded reply. It never
// invents information — it just isn't conversational. This keeps the
// required demo flow (spec section 50, steps 17-19) working even
// without an API key, and is honestly labelled as such in the response.

const env = require('../config/env');
const aiTools = require('./aiTools');
const aiModel = require('../models/aiModel');
const { buildSystemPrompt } = require('../../ai/prompts/systemPrompt');
const { toOpenAiTools, toGeminiTools } = require('../../ai/tools/toolDefinitions');
const { extractSubject } = require('../utils/bookMatcher');

const MAX_TOOL_ITERATIONS = 6;

function isFullModeAvailable() {
  return Boolean(env.AI_API_KEY) && ['openai', 'gemini'].includes(env.AI_PROVIDER);
}

// ---------------------------------------------------------------------
// OpenAI (Chat Completions API, function calling)
// ---------------------------------------------------------------------
async function runOpenAi(studentId, systemPrompt, history, userMessage) {
  const model = env.AI_MODEL || 'gpt-4.1-mini';
  const messages = [
    { role: 'system', content: systemPrompt },
    ...history.map((m) => ({ role: m.role === 'tool' ? 'assistant' : m.role, content: m.content })),
    { role: 'user', content: userMessage },
  ];

  for (let i = 0; i < MAX_TOOL_ITERATIONS; i++) {
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${env.AI_API_KEY}`,
      },
      body: JSON.stringify({
        model,
        messages,
        tools: toOpenAiTools(),
        tool_choice: 'auto',
        temperature: 0.3,
      }),
    });

    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`OpenAI API error (${res.status}): ${errText.slice(0, 300)}`);
    }
    const data = await res.json();
    const message = data.choices[0].message;

    if (message.tool_calls && message.tool_calls.length > 0) {
      messages.push(message);
      for (const call of message.tool_calls) {
        let args = {};
        try { args = JSON.parse(call.function.arguments || '{}'); } catch { /* ignore malformed args */ }
        const result = await aiTools.callTool(call.function.name, studentId, args);
        messages.push({
          role: 'tool',
          tool_call_id: call.id,
          content: JSON.stringify(result),
        });
      }
      continue; // let the model see the tool results and respond again
    }

    return message.content || "I wasn't able to generate a response. Please try again.";
  }
  return "I'm having trouble completing that request right now. Please try rephrasing, or use the dashboard directly.";
}

// ---------------------------------------------------------------------
// Google Gemini (generateContent API, function calling)
// ---------------------------------------------------------------------
async function runGemini(studentId, systemPrompt, history, userMessage) {
  const model = env.AI_MODEL || 'gemini-2.5-flash';
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${env.AI_API_KEY}`;

  const contents = [
    ...history.map((m) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }],
    })),
    { role: 'user', parts: [{ text: userMessage }] },
  ];

  for (let i = 0; i < MAX_TOOL_ITERATIONS; i++) {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        system_instruction: { parts: [{ text: systemPrompt }] },
        contents,
        tools: toGeminiTools(),
        generationConfig: { temperature: 0.3 },
      }),
    });

    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`Gemini API error (${res.status}): ${errText.slice(0, 300)}`);
    }
    const data = await res.json();
    const candidate = data.candidates && data.candidates[0];
    const parts = (candidate && candidate.content && candidate.content.parts) || [];
    const functionCalls = parts.filter((p) => p.functionCall);

    if (functionCalls.length > 0) {
      contents.push({ role: 'model', parts });
      const responseParts = [];
      for (const p of functionCalls) {
        const result = await aiTools.callTool(p.functionCall.name, studentId, p.functionCall.args || {});
        responseParts.push({
          functionResponse: { name: p.functionCall.name, response: { result } },
        });
      }
      contents.push({ role: 'user', parts: responseParts });
      continue;
    }

    const textPart = parts.find((p) => typeof p.text === 'string');
    return (textPart && textPart.text) || "I wasn't able to generate a response. Please try again.";
  }
  return "I'm having trouble completing that request right now. Please try rephrasing, or use the dashboard directly.";
}

// ---------------------------------------------------------------------
// Basic mode (no AI_API_KEY configured) — deterministic, real-data only
// ---------------------------------------------------------------------
async function runBasicMode(studentId, userMessage) {
  const text = userMessage.toLowerCase();

  const wantsBooks = /(my books|which books|currently have|issued books|what do i have)/.test(text);
  const wantsOverdue = /overdue/.test(text);
  const wantsFines = /(fine|fines|penalty|owe)/.test(text);
  const wantsRules = /(how many books|rules|policy|late|limit)/.test(text);
  const wantsRecommend = /(recommend|suggest)/.test(text);
  const wantsRenew = /renew/.test(text);
  const wantsSearch = /(find books|search|books about|books on)/.test(text);
  const wantsDue = /(due|when is)/.test(text);

  const note = "\n\n_(Basic mode — no AI_API_KEY configured, so this is a direct data lookup rather than a conversational answer. Add an OpenAI or Gemini key in .env for natural-language chat.)_";

  if (wantsRenew) {
    const query = extractBookQuery(userMessage);
    const result = await aiTools.check_renewal_eligibility(studentId, { query: query || '' });
    if (!result.found) return `${result.message}${note}`;
    return `${result.title}: ${result.reason} (Renewals used: ${result.renewalsUsed}/${result.maxRenewals}, current due date ${result.dueDate}.)${note}`;
  }

  if (wantsOverdue) {
    const { books } = await aiTools.get_student_books(studentId);
    const overdue = books.filter((b) => b.overdue);
    if (overdue.length === 0) return `You have no overdue books right now.${note}`;
    return `You have ${overdue.length} overdue book(s): ${overdue.map((b) => `${b.title} (due ${b.dueDate})`).join(', ')}.${note}`;
  }

  if (wantsDue && !wantsBooks) {
    const query = extractBookQuery(userMessage);
    const { books } = await aiTools.get_student_books(studentId);
    const match = query ? books.find((b) => b.title.toLowerCase().includes(query.toLowerCase())) : null;
    if (match) return `Your "${match.title}" is due on ${match.dueDate} (${match.daysRemaining >= 0 ? `${match.daysRemaining} day(s) remaining` : 'overdue'}).${note}`;
    if (books.length) return `Here are your due dates: ${books.map((b) => `${b.title} — ${b.dueDate}`).join('; ')}.${note}`;
    return `You don't have any books issued right now.${note}`;
  }

  if (wantsFines) {
    const result = await aiTools.get_student_fines(studentId);
    if (result.totalUnpaid === 0) return `You have no outstanding fines. \u20b90.${note}`;
    return `Your outstanding fine total is \u20b9${result.totalUnpaid}.${note}`;
  }

  if (wantsRules) {
    const r = await aiTools.get_library_rules(studentId);
    return `Library rules: max ${r.maxBooksPerStudent} books at a time, up to ${r.maxRenewalsPerBook} renewals per book, ${r.renewalPeriodDays}-day renewal period, fine of \u20b9${r.finePerDay}/day if overdue.${note}`;
  }

  if (wantsRecommend) {
    const topic = extractTopic(userMessage);
    const result = await aiTools.get_recommendations(studentId, { topic });
    if (result.count === 0) return `I couldn't find recommendations right now — try searching the catalog directly.${note}`;
    return `Recommended for you: ${result.books.map((b) => b.title).join(', ')}.${note}`;
  }

  if (wantsSearch) {
    const topic = extractTopic(userMessage);
    const result = await aiTools.search_books(studentId, { query: topic || userMessage });
    if (result.count === 0) return `No books found matching that.${note}`;
    return `Found ${result.count} book(s): ${result.books.map((b) => `${b.title} (${b.availableCopies > 0 ? 'available' : 'all copies issued'})`).join(', ')}.${note}`;
  }

  if (wantsBooks) {
    const { books, count } = await aiTools.get_student_books(studentId);
    if (count === 0) return `You don't have any books issued right now.${note}`;
    return `You currently have ${count} book(s): ${books.map((b) => `${b.title} (due ${b.dueDate})`).join(', ')}.${note}`;
  }

  return `I can look up your issued books, due dates, overdue status, fines, library rules, and search the catalog. Try asking "which books do I have?" or "can I renew <book>?"${note}`;
}

// Both book-title queries and topic searches reduce to the same
// "strip filler words, keep the subject" heuristic — see bookMatcher.js,
// which also handles common abbreviations (DBMS, OS, CN, ...).
const extractBookQuery = extractSubject;
const extractTopic = extractSubject;

// ---------------------------------------------------------------------
// Public entry point
// ---------------------------------------------------------------------
async function chat({ studentId, conversationId, message }) {
  let convId = conversationId;
  if (!convId) {
    convId = await aiModel.createConversation(studentId, message.slice(0, 60));
  }

  await aiModel.addMessage(convId, 'user', message);
  const historyRows = await aiModel.getMessages(convId, 20);
  const history = historyRows.slice(0, -1).map((r) => ({ role: r.role, content: r.content }));

  let reply;
  let mode;
  try {
    if (isFullModeAvailable()) {
      mode = env.AI_PROVIDER;
      const systemPrompt = buildSystemPrompt();
      reply = env.AI_PROVIDER === 'gemini'
        ? await runGemini(studentId, systemPrompt, history, message)
        : await runOpenAi(studentId, systemPrompt, history, message);
    } else {
      mode = 'basic';
      reply = await runBasicMode(studentId, message);
    }
  } catch (err) {
    console.error('[aiService] provider call failed, falling back to basic mode:', err.message);
    mode = 'basic';
    reply = await runBasicMode(studentId, message);
  }

  await aiModel.addMessage(convId, 'assistant', reply);
  await aiModel.touchConversation(convId);

  return { conversationId: convId, reply, mode };
}

module.exports = { chat, isFullModeAvailable, runBasicMode };
