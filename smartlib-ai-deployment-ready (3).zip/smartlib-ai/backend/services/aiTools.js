// backend/services/aiTools.js
//
// These are the ONLY functions the AI assistant can call (see
// ai/tools/toolDefinitions.js). Every one of them is scoped to a
// single studentId that the backend injects itself — the AI never
// supplies or chooses a student id, so it is architecturally
// impossible for it to read another student's data.
//
// Renewal is deliberately read-only here (check_renewal_eligibility
// only *checks*; it never renews). The actual transaction happens
// through POST /api/books/renew, guarded by renewalService.renewBook,
// after the student explicitly presses "Renew Now".

const issueModel = require('../models/issueModel');
const bookModel = require('../models/bookModel');
const fineModel = require('../models/fineModel');
const settingsModel = require('../models/settingsModel');
const renewalService = require('./renewalService');
const dateUtils = require('../utils/dateUtils');
const { titleMatches, expandForSearch } = require('../utils/bookMatcher');

async function get_student_books(studentId) {
  const issues = await issueModel.findActiveByStudent(studentId);
  return {
    count: issues.length,
    books: issues.map((i) => ({
      issueId: i.id,
      bookId: i.book_code,
      title: i.title,
      author: i.author,
      issueDate: i.issue_date,
      dueDate: i.due_date,
      daysRemaining: dateUtils.daysBetween(dateUtils.todayISO(), i.due_date),
      renewalCount: i.renewal_count,
      overdue: dateUtils.isPast(i.due_date, dateUtils.todayISO()),
    })),
  };
}

async function findIssueByQuery(studentId, query) {
  const issues = await issueModel.findActiveByStudent(studentId);
  const q = (query || '').trim();
  if (!q) return null;
  // Try exact book_id first, then fuzzy/alias title matching (handles "DBMS" -> "Database Management Systems").
  const byCode = issues.find((i) => i.book_code.toLowerCase() === q.toLowerCase());
  if (byCode) return byCode;
  return issues.find((i) => titleMatches(q, i.title)) || null;
}

async function get_book_details(studentId, { query }) {
  let book = await bookModel.findByBookId((query || '').toUpperCase());
  if (!book) {
    const results = await bookModel.search({ q: expandForSearch(query), limit: 5 });
    book = results.find((b) => titleMatches(query, b.title)) || results[0] || null;
  }
  if (!book) return { found: false, message: `No book matching "${query}" was found in the catalog.` };
  return {
    found: true,
    bookId: book.book_id,
    title: book.title,
    author: book.author,
    isbn: book.isbn,
    publisher: book.publisher,
    edition: book.edition,
    category: book.category_name,
    shelfNumber: book.shelf_number,
    availableCopies: book.available_quantity,
    totalCopies: book.quantity,
  };
}

async function check_renewal_eligibility(studentId, { query }) {
  const issue = await findIssueByQuery(studentId, query);
  if (!issue) {
    return { found: false, message: `You don't currently have a book matching "${query}" issued.` };
  }
  const verdict = await renewalService.checkEligibility(issue);
  return {
    found: true,
    issueId: issue.id,
    bookId: issue.book_code,
    title: issue.title,
    dueDate: issue.due_date,
    renewalsUsed: verdict.renewalsUsed,
    maxRenewals: verdict.maxRenewals,
    eligible: verdict.eligible,
    reason: verdict.reason,
  };
}

async function search_books(studentId, { query }) {
  const results = await bookModel.search({ q: expandForSearch(query), limit: 8 });
  return {
    count: results.length,
    books: results.map((b) => ({
      bookId: b.book_id,
      title: b.title,
      author: b.author,
      category: b.category_name,
      availableCopies: b.available_quantity,
    })),
  };
}

async function get_student_fines(studentId) {
  const fines = await fineModel.findByStudent(studentId);
  const totalUnpaid = await fineModel.totalUnpaidByStudent(studentId);
  return {
    totalUnpaid,
    fines: fines.map((f) => ({
      book: f.title,
      amount: Number(f.amount),
      status: f.status,
      reason: f.reason,
      createdAt: f.created_at,
    })),
  };
}

async function get_library_rules(studentId) {
  const s = await settingsModel.getAll();
  return {
    maxBooksPerStudent: Number(s.max_books_per_student),
    maxRenewalsPerBook: Number(s.max_renewals_per_book),
    loanPeriodDays: Number(s.loan_period_days),
    renewalPeriodDays: Number(s.renewal_period_days),
    finePerDay: Number(s.fine_per_day),
    maxUnpaidFineAllowed: Number(s.max_unpaid_fine_allowed),
  };
}

async function get_recommendations(studentId, { topic } = {}) {
  const issues = await issueModel.findActiveByStudent(studentId);
  const bookIds = issues.map((i) => i.book_id);

  let categoryIds = [];
  if (bookIds.length) {
    const books = await Promise.all(bookIds.map((id) => bookModel.findById(id)));
    categoryIds = [...new Set(books.filter((b) => b && b.category_id).map((b) => b.category_id))];
  }

  let recs = [];
  if (categoryIds.length) {
    recs = await bookModel.recommendSimilar(categoryIds, bookIds, 5);
  }
  if (recs.length === 0 && topic) {
    recs = await bookModel.search({ q: topic, limit: 5 });
  }
  return {
    count: recs.length,
    books: recs.map((b) => ({
      bookId: b.book_id,
      title: b.title,
      author: b.author,
      category: b.category_name,
      availableCopies: b.available_quantity,
    })),
  };
}

// Registry the AI service dispatches through, keyed by tool name.
const registry = {
  get_student_books,
  get_book_details,
  check_renewal_eligibility,
  search_books,
  get_student_fines,
  get_library_rules,
  get_recommendations,
};

/**
 * Executes a named tool for a given student. `args` comes from the
 * model's tool call and is treated as untrusted input — each function
 * above only ever reads/writes data scoped to `studentId`.
 */
async function callTool(name, studentId, args = {}) {
  const fn = registry[name];
  if (!fn) return { error: `Unknown tool: ${name}` };
  try {
    return await fn(studentId, args);
  } catch (err) {
    console.error(`[aiTools] ${name} failed:`, err.message);
    return { error: 'This lookup failed on the server. Please try again.' };
  }
}

module.exports = { registry, callTool, ...registry };
