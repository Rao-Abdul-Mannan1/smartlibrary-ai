// backend/services/emailService.js
//
// Sends verification OTPs, password resets, and notification emails
// via nodemailer using the MAIL_* env vars (section 54). If no SMTP
// credentials are configured, the app still runs — this is a common,
// honestly-documented dev-mode fallback: instead of silently failing,
// it logs the email to the server console AND returns `devPreview` in
// the API response so student1/student2/student3 demo accounts can be
// verified without a real mail server. In production, set MAIL_HOST /
// MAIL_USERNAME / MAIL_PASSWORD and this fallback never triggers.

const nodemailer = require('nodemailer');
const env = require('../config/env');

function isConfigured() {
  return Boolean(env.MAIL_HOST && env.MAIL_USERNAME && env.MAIL_PASSWORD);
}

let transporter = null;
function getTransporter() {
  if (!isConfigured()) return null;
  if (!transporter) {
    transporter = nodemailer.createTransport({
      host: env.MAIL_HOST,
      port: env.MAIL_PORT,
      secure: env.MAIL_PORT === 465,
      auth: { user: env.MAIL_USERNAME, pass: env.MAIL_PASSWORD },
    });
  }
  return transporter;
}

async function send({ to, subject, html, text }) {
  const t = getTransporter();
  if (!t) {
    console.log(`\n[emailService] DEV MODE — SMTP not configured. Would send email:`);
    console.log(`  To: ${to}\n  Subject: ${subject}\n  Body: ${text || html}\n`);
    return { delivered: false, devPreview: text || html };
  }
  await t.sendMail({ from: env.MAIL_FROM, to, subject, html, text });
  return { delivered: true, devPreview: null };
}

async function sendOtpEmail(to, code, purpose) {
  const subject = purpose === 'reset_password'
    ? 'SmartLib AI — Password reset code'
    : 'SmartLib AI — Verify your email';
  const text = `Your SmartLib AI verification code is: ${code}\nThis code expires in 15 minutes.\nIf you did not request this, you can ignore this email.`;
  const html = `<p>Your SmartLib AI verification code is:</p><h2 style="letter-spacing:4px">${code}</h2><p>This code expires in 15 minutes.</p>`;
  return send({ to, subject, html, text });
}

module.exports = { isConfigured, send, sendOtpEmail };
