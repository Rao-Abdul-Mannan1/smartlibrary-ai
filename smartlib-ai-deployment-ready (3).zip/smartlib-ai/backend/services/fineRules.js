// backend/services/fineRules.js
// Pure fine calculation — no DB, no requires beyond dateUtils (also pure).
const dateUtils = require('../utils/dateUtils');

/**
 * Fine = ratePerDay × overdue days (0 if not overdue).
 * @param {object} p
 * @param {string} p.dueDate     'YYYY-MM-DD'
 * @param {string} p.returnDate  'YYYY-MM-DD' (or "today" for a live/unreturned estimate)
 * @param {number} p.ratePerDay  configurable via library_settings.fine_per_day
 */
function calculateFine({ dueDate, returnDate, ratePerDay }) {
  const overdueDays = Math.max(0, dateUtils.daysBetween(dueDate, returnDate));
  const amount = Math.round(overdueDays * ratePerDay * 100) / 100;
  return { overdueDays, amount };
}

module.exports = { calculateFine };
