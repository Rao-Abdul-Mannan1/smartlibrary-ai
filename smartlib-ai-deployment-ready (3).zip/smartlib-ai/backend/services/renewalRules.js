// backend/services/renewalRules.js
//
// Pure decision logic for "can this book be renewed?" — no DB, no I/O,
// no external requires. This is intentionally isolated from
// renewalService.js (which fetches the facts from the database and
// wraps this in a transaction) so the actual business rule can be
// unit tested with nothing but plain Node. Run:
//   node backend/services/renewalRules.test.js

/**
 * @param {object} facts
 * @param {number} facts.renewalCount           renewals already used on this issue
 * @param {number} facts.maxRenewals             rule: max renewals per book
 * @param {boolean} facts.isReservedByOther
 * @param {boolean} facts.studentHasOtherOverdue  (or this issue itself is overdue)
 * @param {number} facts.unpaidFineTotal
 * @param {number} facts.maxUnpaidFineAllowed
 * @param {string} facts.accountStatus           'active' | 'blocked' | 'pending' | 'deactivated'
 * @param {boolean} facts.alreadyReturned
 * @returns {{ eligible: boolean, reasonCode: string|null, reason: string|null }}
 */
function evaluateEligibility(facts) {
  const {
    accountStatus,
    alreadyReturned,
    renewalCount,
    maxRenewals,
    isReservedByOther,
    studentHasOtherOverdue,
    unpaidFineTotal,
    maxUnpaidFineAllowed,
  } = facts;

  if (accountStatus === 'blocked') {
    return { eligible: false, reasonCode: 'ACCOUNT_BLOCKED', reason: 'Your library account is blocked. Please contact the library desk.' };
  }
  if (alreadyReturned) {
    return { eligible: false, reasonCode: 'ALREADY_RETURNED', reason: 'This book has already been returned and cannot be renewed.' };
  }
  if (renewalCount >= maxRenewals) {
    return { eligible: false, reasonCode: 'RENEWAL_LIMIT_REACHED', reason: 'This book has already reached its maximum renewal limit.' };
  }
  if (isReservedByOther) {
    return { eligible: false, reasonCode: 'RESERVED_BY_OTHER', reason: 'This book cannot be renewed because another student has reserved it.' };
  }
  if (studentHasOtherOverdue) {
    return { eligible: false, reasonCode: 'HAS_OVERDUE', reason: 'Please return your overdue book before requesting another renewal.' };
  }
  if (unpaidFineTotal > maxUnpaidFineAllowed) {
    return { eligible: false, reasonCode: 'FINE_LIMIT_EXCEEDED', reason: 'Renewal unavailable because your outstanding fine exceeds the allowed limit.' };
  }

  return { eligible: true, reasonCode: null, reason: 'This book is eligible for renewal.' };
}

module.exports = { evaluateEligibility };
