// backend/services/auditService.js
const auditModel = require('../models/auditModel');

async function log(userId, action, target = null, details = null) {
  try {
    await auditModel.log({ userId, action, target, details });
  } catch (err) {
    // Auditing must never break the primary request flow.
    console.error('[auditService] failed to write audit log:', err.message);
  }
}

module.exports = { log };
