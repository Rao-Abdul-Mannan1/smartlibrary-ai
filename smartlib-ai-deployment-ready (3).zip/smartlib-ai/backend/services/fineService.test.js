// backend/services/fineService.test.js
// Run with: node backend/services/fineService.test.js
const assert = require('assert');
const { calculateFine } = require('./fineRules');

let passed = 0;
function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  ok - ${name}`);
  } catch (err) {
    console.error(`  FAIL - ${name}\n         ${err.message}`);
    process.exitCode = 1;
  }
}

console.log('fineRules.calculateFine');

test('no fine when returned on the due date', () => {
  const r = calculateFine({ dueDate: '2026-09-20', returnDate: '2026-09-20', ratePerDay: 5 });
  assert.strictEqual(r.overdueDays, 0);
  assert.strictEqual(r.amount, 0);
});

test('no fine when returned early', () => {
  const r = calculateFine({ dueDate: '2026-09-20', returnDate: '2026-09-18', ratePerDay: 5 });
  assert.strictEqual(r.overdueDays, 0);
  assert.strictEqual(r.amount, 0);
});

test('example from spec: Due 10 Sept, current 18 Sept -> 8 days overdue', () => {
  const r = calculateFine({ dueDate: '2026-09-10', returnDate: '2026-09-18', ratePerDay: 5 });
  assert.strictEqual(r.overdueDays, 8);
  assert.strictEqual(r.amount, 40);
});

test('fine scales linearly with configurable rate', () => {
  const r = calculateFine({ dueDate: '2026-09-10', returnDate: '2026-09-15', ratePerDay: 2.5 });
  assert.strictEqual(r.overdueDays, 5);
  assert.strictEqual(r.amount, 12.5);
});

console.log(`\n${passed} test(s) passed.`);
