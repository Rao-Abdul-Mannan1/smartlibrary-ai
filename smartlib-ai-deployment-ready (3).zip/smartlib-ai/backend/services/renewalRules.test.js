// backend/services/renewalRules.test.js
// Plain-Node unit tests (no test framework dependency) for the core
// renewal eligibility rules. Run with:  node backend/services/renewalRules.test.js
const assert = require('assert');
const { evaluateEligibility } = require('./renewalRules');

const baseFacts = {
  accountStatus: 'active',
  alreadyReturned: false,
  renewalCount: 0,
  maxRenewals: 2,
  isReservedByOther: false,
  studentHasOtherOverdue: false,
  unpaidFineTotal: 0,
  maxUnpaidFineAllowed: 100,
};

let passed = 0;
function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  ok - ${name}`);
  } catch (err) {
    console.error(`  FAIL - ${name}`);
    console.error(`         ${err.message}`);
    process.exitCode = 1;
  }
}

console.log('renewalRules.evaluateEligibility');

test('eligible when all conditions are clean', () => {
  const v = evaluateEligibility(baseFacts);
  assert.strictEqual(v.eligible, true);
  assert.strictEqual(v.reasonCode, null);
});

test('blocked account is never eligible, even with 0 renewals used', () => {
  const v = evaluateEligibility({ ...baseFacts, accountStatus: 'blocked' });
  assert.strictEqual(v.eligible, false);
  assert.strictEqual(v.reasonCode, 'ACCOUNT_BLOCKED');
});

test('already-returned book cannot be renewed', () => {
  const v = evaluateEligibility({ ...baseFacts, alreadyReturned: true });
  assert.strictEqual(v.eligible, false);
  assert.strictEqual(v.reasonCode, 'ALREADY_RETURNED');
});

test('renewal limit reached (renewalCount == maxRenewals)', () => {
  const v = evaluateEligibility({ ...baseFacts, renewalCount: 2, maxRenewals: 2 });
  assert.strictEqual(v.eligible, false);
  assert.strictEqual(v.reasonCode, 'RENEWAL_LIMIT_REACHED');
});

test('renewal allowed one below the limit (renewalCount == maxRenewals - 1)', () => {
  const v = evaluateEligibility({ ...baseFacts, renewalCount: 1, maxRenewals: 2 });
  assert.strictEqual(v.eligible, true);
});

test('reserved by another student blocks renewal', () => {
  const v = evaluateEligibility({ ...baseFacts, isReservedByOther: true });
  assert.strictEqual(v.eligible, false);
  assert.strictEqual(v.reasonCode, 'RESERVED_BY_OTHER');
});

test('an overdue book elsewhere on the account blocks renewal', () => {
  const v = evaluateEligibility({ ...baseFacts, studentHasOtherOverdue: true });
  assert.strictEqual(v.eligible, false);
  assert.strictEqual(v.reasonCode, 'HAS_OVERDUE');
});

test('unpaid fine over the allowed limit blocks renewal', () => {
  const v = evaluateEligibility({ ...baseFacts, unpaidFineTotal: 150, maxUnpaidFineAllowed: 100 });
  assert.strictEqual(v.eligible, false);
  assert.strictEqual(v.reasonCode, 'FINE_LIMIT_EXCEEDED');
});

test('unpaid fine exactly at the limit is still allowed (limit is exclusive upper bound)', () => {
  const v = evaluateEligibility({ ...baseFacts, unpaidFineTotal: 100, maxUnpaidFineAllowed: 100 });
  assert.strictEqual(v.eligible, true);
});

test('blocked account beats every other failure reason (checked first)', () => {
  const v = evaluateEligibility({
    ...baseFacts,
    accountStatus: 'blocked',
    renewalCount: 5,
    maxRenewals: 2,
    isReservedByOther: true,
    unpaidFineTotal: 999,
  });
  assert.strictEqual(v.reasonCode, 'ACCOUNT_BLOCKED');
});

console.log(`\n${passed} test(s) passed.`);
