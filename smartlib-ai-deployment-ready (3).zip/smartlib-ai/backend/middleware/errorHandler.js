// backend/middleware/errorHandler.js
const { ApiError } = require('../utils/apiResponse');
const env = require('../config/env');

// 404 handler — must be registered after all routes.
function notFound(req, res) {
  res.status(404).json({ success: false, error: { message: 'Route not found', code: 'NOT_FOUND' } });
}

// Central error handler — must be registered last, with 4 args.
function errorHandler(err, req, res, next) { // eslint-disable-line no-unused-vars
  if (err instanceof ApiError) {
    return res.status(err.statusCode).json({ success: false, error: { message: err.message, code: err.code } });
  }

  // MySQL duplicate entry, FK violation, etc.
  if (err && err.code === 'ER_DUP_ENTRY') {
    return res.status(409).json({ success: false, error: { message: 'That record already exists.', code: 'DUPLICATE' } });
  }

  console.error('[error]', err);
  const message = env.NODE_ENV === 'development' ? err.message : 'Something went wrong. Please try again.';
  res.status(500).json({ success: false, error: { message, code: 'INTERNAL_ERROR' } });
}

module.exports = { notFound, errorHandler };
