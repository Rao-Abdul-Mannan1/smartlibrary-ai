// backend/middleware/rateLimiter.js
// Protects sensitive endpoints (login, register, OTP, AI chat) from abuse.
const rateLimit = require('express-rate-limit');

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: { message: 'Too many attempts. Please try again later.', code: 'RATE_LIMITED' } },
});

const otpLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: { message: 'Too many OTP requests. Please wait before retrying.', code: 'RATE_LIMITED' } },
});

const aiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 15,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: { message: 'You are sending messages too quickly. Please slow down.', code: 'RATE_LIMITED' } },
});

module.exports = { authLimiter, otpLimiter, aiLimiter };
