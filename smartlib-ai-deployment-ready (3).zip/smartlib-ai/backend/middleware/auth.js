// backend/middleware/auth.js
// JWT verification + role-based access control.
// Students can NEVER reach admin-only routes, and vice versa —
// this is enforced here, centrally, not left to each controller.

const jwt = require('jsonwebtoken');
const env = require('../config/env');
const { fail } = require('../utils/apiResponse');

function verifyToken(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;

  if (!token) {
    return fail(res, 401, 'Authentication required. Please log in.', 'UNAUTHENTICATED');
  }

  try {
    const payload = jwt.verify(token, env.JWT_SECRET);
    // payload: { userId, role, studentRowId? , adminRowId? }
    req.user = payload;
    next();
  } catch (err) {
    return fail(res, 401, 'Session expired or invalid. Please log in again.', 'INVALID_TOKEN');
  }
}

function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return fail(res, 403, 'You do not have permission to access this resource.', 'FORBIDDEN');
    }
    next();
  };
}

const requireStudent = requireRole('student');
const requireAdmin = requireRole('admin');

module.exports = { verifyToken, requireRole, requireStudent, requireAdmin };
