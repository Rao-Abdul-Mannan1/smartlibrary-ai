// backend/routes/aiRoutes.js
const router = require('express').Router();
const ctrl = require('../controllers/aiController');
const { verifyToken, requireStudent } = require('../middleware/auth');
const { aiLimiter } = require('../middleware/rateLimiter');

router.use(verifyToken, requireStudent);
router.post('/chat', aiLimiter, ctrl.chat);
router.get('/history', ctrl.history);
router.get('/status', ctrl.status);

module.exports = router;
