// backend/routes/authRoutes.js
const router = require('express').Router();
const ctrl = require('../controllers/authController');
const { verifyToken } = require('../middleware/auth');
const { authLimiter, otpLimiter } = require('../middleware/rateLimiter');

router.post('/register', authLimiter, ctrl.register);
router.post('/verify-email', otpLimiter, ctrl.verifyEmail);
router.post('/resend-otp', otpLimiter, ctrl.resendOtp);
router.post('/login', authLimiter, ctrl.login);
router.post('/forgot-password', otpLimiter, ctrl.forgotPassword);
router.post('/reset-password', otpLimiter, ctrl.resetPassword);
router.get('/me', verifyToken, ctrl.me);

module.exports = router;
