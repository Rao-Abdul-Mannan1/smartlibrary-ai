// backend/routes/bookRoutes.js
const router = require('express').Router();
const ctrl = require('../controllers/bookController');
const renewalCtrl = require('../controllers/renewalController');
const { verifyToken, requireStudent, requireAdmin } = require('../middleware/auth');
const { uploadCover } = require('../middleware/upload');

// Public/shared reads
router.get('/', ctrl.listBooks);
router.get('/categories', ctrl.listCategories);
router.get('/:id', ctrl.getBook);
router.get('/:id/qr', verifyToken, requireAdmin, ctrl.downloadQr);

// Student actions
router.post('/scan', verifyToken, requireStudent, ctrl.scanBook);
router.post('/renew', verifyToken, requireStudent, renewalCtrl.renewBook);

// Admin CRUD
router.post('/', verifyToken, requireAdmin, ctrl.createBook);
router.put('/:id', verifyToken, requireAdmin, ctrl.updateBook);
router.put('/:id/cover', verifyToken, requireAdmin, uploadCover.single('cover'), ctrl.uploadCover);
router.delete('/:id', verifyToken, requireAdmin, ctrl.deleteBook);

module.exports = router;
