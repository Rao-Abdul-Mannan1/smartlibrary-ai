// backend/routes/adminRoutes.js
const router = require('express').Router();
const ctrl = require('../controllers/adminController');
const issueCtrl = require('../controllers/issueController');
const { verifyToken, requireAdmin } = require('../middleware/auth');

router.use(verifyToken, requireAdmin);

router.get('/dashboard', ctrl.dashboard);
router.get('/students', ctrl.listStudents);
router.get('/students/:id', ctrl.getStudent);
router.post('/students', ctrl.createStudent);
router.put('/students/:id/status', ctrl.setStudentStatus);
router.get('/audit-log', ctrl.auditLog);

router.post('/issues', issueCtrl.issueBook);
router.post('/issues/return', issueCtrl.returnBook);
router.get('/issues/overdue', issueCtrl.overdueList);

module.exports = router;
