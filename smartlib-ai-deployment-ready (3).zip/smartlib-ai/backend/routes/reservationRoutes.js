// backend/routes/reservationRoutes.js
const router = require('express').Router();
const ctrl = require('../controllers/reservationController');
const { verifyToken, requireStudent, requireAdmin } = require('../middleware/auth');

router.post('/', verifyToken, requireStudent, ctrl.createReservation);
router.delete('/:id', verifyToken, requireStudent, ctrl.cancelReservation);
router.get('/', verifyToken, requireAdmin, ctrl.listReservations);

module.exports = router;
