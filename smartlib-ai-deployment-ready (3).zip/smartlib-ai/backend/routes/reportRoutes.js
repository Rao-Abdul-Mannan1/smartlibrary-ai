// backend/routes/reportRoutes.js
const router = require('express').Router();
const ctrl = require('../controllers/reportController');
const { verifyToken, requireAdmin } = require('../middleware/auth');

router.use(verifyToken, requireAdmin);
router.get('/charts', ctrl.charts);
router.get('/most-borrowed', ctrl.mostBorrowed);
router.get('/most-active-students', ctrl.mostActiveStudents);
router.get('/overdue', ctrl.overdueReport);
router.get('/renewals', ctrl.renewalStats);
router.get('/fines', ctrl.fineReport);
router.get('/availability', ctrl.availabilityReport);

module.exports = router;
