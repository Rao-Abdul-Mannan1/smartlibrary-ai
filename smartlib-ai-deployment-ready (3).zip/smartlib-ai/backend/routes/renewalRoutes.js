// backend/routes/renewalRoutes.js
const router = require('express').Router();
const ctrl = require('../controllers/renewalController');
const { verifyToken, requireStudent, requireAdmin } = require('../middleware/auth');

router.get('/check/:issueId', verifyToken, requireStudent, ctrl.checkEligibility);
router.get('/', verifyToken, requireAdmin, ctrl.listRenewals);
router.post('/admin', verifyToken, requireAdmin, ctrl.adminRenewBook);

module.exports = router;
