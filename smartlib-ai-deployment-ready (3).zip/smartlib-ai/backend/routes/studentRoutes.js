// backend/routes/studentRoutes.js
const router = require('express').Router();
const ctrl = require('../controllers/studentController');
const fineCtrl = require('../controllers/fineController');
const reservationCtrl = require('../controllers/reservationController');
const { verifyToken, requireStudent } = require('../middleware/auth');

router.use(verifyToken, requireStudent);

router.get('/dashboard', ctrl.dashboard);
router.get('/books', ctrl.myBooks);
router.get('/history', ctrl.history);
router.get('/renewals', ctrl.renewalHistory);
router.get('/fines', fineCtrl.myFines);
router.get('/reservations', reservationCtrl.myReservations);
router.get('/profile', ctrl.getProfile);
router.put('/profile', ctrl.updateProfile);

module.exports = router;
