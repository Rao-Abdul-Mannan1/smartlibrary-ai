// backend/routes/fineRoutes.js
const router = require('express').Router();
const ctrl = require('../controllers/fineController');
const { verifyToken, requireAdmin } = require('../middleware/auth');

router.get('/', verifyToken, requireAdmin, ctrl.listFines);
router.put('/:id', verifyToken, requireAdmin, ctrl.updateFineStatus);

module.exports = router;
