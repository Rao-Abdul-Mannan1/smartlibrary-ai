// backend/routes/settingsRoutes.js
const router = require('express').Router();
const ctrl = require('../controllers/settingsController');
const { verifyToken, requireAdmin } = require('../middleware/auth');

router.get('/', ctrl.getSettings); // public read — powers the Library Rules page
router.put('/', verifyToken, requireAdmin, ctrl.updateSettings);

module.exports = router;
