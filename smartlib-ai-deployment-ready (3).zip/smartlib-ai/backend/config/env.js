// backend/config/env.js
// Central place that reads and validates environment variables.
require('dotenv').config();

function required(name, fallback) {
  const value = process.env[name];
  if (value === undefined || value === '') {
    if (fallback !== undefined) return fallback;
    console.warn(`[env] Warning: ${name} is not set.`);
    return '';
  }
  return value;
}

const env = {
  NODE_ENV: process.env.NODE_ENV || 'development',
  PORT: parseInt(process.env.PORT || '4000', 10),

  // Database
  DB_HOST: required('DB_HOST', '127.0.0.1'),
  DB_PORT: parseInt(process.env.DB_PORT || '3306', 10),
  DB_NAME: required('DB_NAME', 'smartlib_ai'),
  DB_USER: required('DB_USER', 'root'),
  DB_PASSWORD: process.env.DB_PASSWORD || '',

  // Auth
  JWT_SECRET: required('JWT_SECRET', 'dev-only-insecure-secret-change-me'),
  JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN || '7d',
  BCRYPT_SALT_ROUNDS: parseInt(process.env.BCRYPT_SALT_ROUNDS || '10', 10),

  // College email restriction
  COLLEGE_EMAIL_DOMAIN: required('COLLEGE_EMAIL_DOMAIN', '@college-domain.ac.in'),

  // AI
  AI_PROVIDER: (process.env.AI_PROVIDER || 'openai').toLowerCase(),
  AI_API_KEY: process.env.AI_API_KEY || '',
  AI_MODEL: process.env.AI_MODEL || '',

  // Mail
  MAIL_HOST: process.env.MAIL_HOST || '',
  MAIL_PORT: parseInt(process.env.MAIL_PORT || '587', 10),
  MAIL_USERNAME: process.env.MAIL_USERNAME || '',
  MAIL_PASSWORD: process.env.MAIL_PASSWORD || '',
  MAIL_FROM: process.env.MAIL_FROM || 'SmartLib AI <no-reply@smartlib.ai>',

  // Public app / CORS
  APP_URL: process.env.APP_URL || 'http://localhost:4000',
  FRONTEND_URL: process.env.FRONTEND_URL || '',
};

function validateProduction() {
  if (env.NODE_ENV !== 'production') return;

  const errors = [];
  if (!env.DB_HOST || !env.DB_NAME || !env.DB_USER) errors.push('DB_HOST, DB_NAME and DB_USER are required');
  if (!env.JWT_SECRET || env.JWT_SECRET === 'dev-only-insecure-secret-change-me' || env.JWT_SECRET.length < 32) {
    errors.push('JWT_SECRET must be a random value of at least 32 characters');
  }
  if (!env.COLLEGE_EMAIL_DOMAIN || env.COLLEGE_EMAIL_DOMAIN === '@college-domain.ac.in') {
    errors.push('COLLEGE_EMAIL_DOMAIN must be set to the real college email domain');
  }
  if (!['openai', 'gemini', 'none'].includes(env.AI_PROVIDER)) {
    errors.push('AI_PROVIDER must be openai, gemini, or none');
  }
  if (env.AI_PROVIDER !== 'none' && !env.AI_API_KEY) {
    console.warn('[env] AI_API_KEY is not set; AI assistant will run in basic mode.');
  }

  if (errors.length) {
    throw new Error(`Production environment validation failed:\n- ${errors.join('\n- ')}`);
  }
}

validateProduction();
module.exports = env;
