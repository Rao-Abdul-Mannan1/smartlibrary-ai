// backend/config/db.js
// A single mysql2 connection pool shared across the whole app.
// Every query anywhere in the codebase goes through pool.execute(),
// which uses server-side prepared statements — never raw string
// concatenation — to prevent SQL injection.

const mysql = require('mysql2/promise');
const env = require('./env');

const pool = mysql.createPool({
  host: env.DB_HOST,
  port: env.DB_PORT,
  user: env.DB_USER,
  password: env.DB_PASSWORD,
  database: env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  dateStrings: true, // return DATE/DATETIME as 'YYYY-MM-DD' strings, easier to reason about
});

// Helper for running a set of queries inside a single transaction.
// Usage: await withTransaction(async (conn) => { ... conn.execute(...) ... });
async function withTransaction(fn) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const result = await fn(conn);
    await conn.commit();
    return result;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

async function testConnection() {
  try {
    const conn = await pool.getConnection();
    await conn.ping();
    conn.release();
    console.log('[db] MySQL connection OK');
    return true;
  } catch (err) {
    console.error('[db] MySQL connection FAILED:', err.message);
    return false;
  }
}

module.exports = { pool, withTransaction, testConnection };
