// backend/controllers/adminController.js
const bcrypt = require('bcryptjs');
const env = require('../config/env');
const { withTransaction } = require('../config/db');
const bookModel = require('../models/bookModel');
const studentModel = require('../models/studentModel');
const issueModel = require('../models/issueModel');
const fineModel = require('../models/fineModel');
const renewalModel = require('../models/renewalModel');
const userModel = require('../models/userModel');
const auditModel = require('../models/auditModel');
const auditService = require('../services/auditService');
const { isCollegeEmail, isNonEmptyString } = require('../utils/validators');
const { ApiError, ok } = require('../utils/apiResponse');
const asyncHandler = require('../utils/asyncHandler');

// GET /api/admin/dashboard — every figure is a live query, nothing hard-coded (spec section 51)
const dashboard = asyncHandler(async (req, res) => {
  const [
    totalBooks, availableBooks, issuedCopies, totalStudents,
    overdueBooks, pendingRenewals, totalFinesOutstanding, totalFinesCollected,
  ] = await Promise.all([
    bookModel.countTotal(),
    bookModel.countAvailable(),
    bookModel.countIssuedCopies(),
    studentModel.count(),
    issueModel.countOverdue(),
    renewalModel.countTotal(),
    fineModel.totalOutstanding(),
    fineModel.totalCollected(),
  ]);

  ok(res, {
    stats: {
      totalBooks, availableBooks, issuedBooks: issuedCopies, totalStudents,
      overdueBooks, pendingRenewals, totalFinesOutstanding, totalFinesCollected,
    },
  });
});

// GET /api/admin/students
const listStudents = asyncHandler(async (req, res) => {
  const { q, limit, offset } = req.query;
  const rows = q
    ? await studentModel.search(q, Math.min(parseInt(limit, 10) || 50, 100))
    : await studentModel.listAll({ limit: Math.min(parseInt(limit, 10) || 50, 100), offset: parseInt(offset, 10) || 0 });
  ok(res, { students: rows });
});

// GET /api/admin/students/:id — full profile with books/fines/renewal history
const getStudent = asyncHandler(async (req, res) => {
  const student = await studentModel.findById(req.params.id);
  if (!student) throw new ApiError(404, 'Student not found.', 'NOT_FOUND');

  const [books, fines, renewals] = await Promise.all([
    issueModel.findActiveByStudent(student.id),
    fineModel.findByStudent(student.id),
    renewalModel.findByStudent(student.id),
  ]);

  ok(res, {
    student,
    books: books.map((b) => ({ title: b.title, dueDate: b.due_date, status: b.status })),
    fines: fines.map((f) => ({ book: f.title, amount: Number(f.amount), status: f.status })),
    renewals: renewals.map((r) => ({ book: r.title, newDueDate: r.new_due_date, createdAt: r.created_at })),
  });
});

// POST /api/admin/students  (admin manually adds a student account)
const createStudent = asyncHandler(async (req, res) => {
  const { name, email, studentId, course, semester, department, password } = req.body;
  if (!isNonEmptyString(name, 150)) throw new ApiError(400, 'Name is required.', 'VALIDATION');
  if (!isCollegeEmail(email)) throw new ApiError(400, 'Please use a valid college email address.', 'INVALID_DOMAIN');
  if (!isNonEmptyString(studentId, 50)) throw new ApiError(400, 'Student ID is required.', 'VALIDATION');

  const existing = await userModel.findByEmail(email.toLowerCase());
  if (existing) throw new ApiError(409, 'An account with this email already exists.', 'DUPLICATE');

  const tempPassword = password || Math.random().toString(36).slice(-10);
  const passwordHash = await bcrypt.hash(tempPassword, env.BCRYPT_SALT_ROUNDS);

  const userId = await withTransaction(async (conn) => {
    const uid = await userModel.create(conn, { name, email: email.toLowerCase(), passwordHash, role: 'student' });
    await conn.execute("UPDATE users SET status = 'active', email_verified = 1 WHERE id = ?", [uid]);
    await studentModel.create(conn, { userId: uid, studentId, course, semester, department });
    return uid;
  });

  await auditService.log(req.user.userId, 'student_added', `user:${userId}`, { studentId });
  ok(res, { message: 'Student account created.', userId, temporaryPassword: password ? undefined : tempPassword }, 201);
});

// PUT /api/admin/students/:id/status  Body: { status: 'active'|'blocked'|'deactivated' }
const setStudentStatus = asyncHandler(async (req, res) => {
  const { status } = req.body;
  if (!['active', 'blocked', 'deactivated'].includes(status)) {
    throw new ApiError(400, 'Invalid status.', 'VALIDATION');
  }
  const student = await studentModel.findById(req.params.id);
  if (!student) throw new ApiError(404, 'Student not found.', 'NOT_FOUND');

  await userModel.setStatus(student.user_id, status);
  await auditService.log(req.user.userId, 'student_status_changed', `student:${student.id}`, { status });
  ok(res, { message: `Student account set to ${status}.` });
});

// GET /api/admin/audit-log
const auditLog = asyncHandler(async (req, res) => {
  const rows = await auditModel.recent(150);
  ok(res, { logs: rows });
});

module.exports = { dashboard, listStudents, getStudent, createStudent, setStudentStatus, auditLog };
