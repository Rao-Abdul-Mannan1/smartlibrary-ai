// backend/controllers/studentController.js
const studentModel = require('../models/studentModel');
const issueModel = require('../models/issueModel');
const fineModel = require('../models/fineModel');
const renewalModel = require('../models/renewalModel');
const settingsModel = require('../models/settingsModel');
const userModel = require('../models/userModel');
const dateUtils = require('../utils/dateUtils');
const { ApiError, ok } = require('../utils/apiResponse');
const asyncHandler = require('../utils/asyncHandler');
const { isNonEmptyString } = require('../utils/validators');

function bookStatus(issue) {
  const daysRemaining = dateUtils.daysBetween(dateUtils.todayISO(), issue.due_date);
  if (issue.status === 'returned') return 'returned';
  if (daysRemaining < 0) return 'overdue';
  if (daysRemaining <= 3) return 'due_soon';
  return 'active';
}

function serializeIssue(issue, maxRenewals) {
  const daysRemaining = dateUtils.daysBetween(dateUtils.todayISO(), issue.due_date);
  return {
    issueId: issue.id,
    bookId: issue.book_id,
    bookCode: issue.book_code,
    title: issue.title,
    author: issue.author,
    coverImage: issue.cover_image,
    issueDate: issue.issue_date,
    dueDate: issue.due_date,
    daysRemaining,
    renewalCount: issue.renewal_count,
    maxRenewals,
    status: bookStatus(issue),
    renewable: issue.renewal_count < maxRenewals && daysRemaining !== null,
  };
}

// GET /api/student/dashboard — stat cards + issued books, all from real data (no hard-coded numbers)
const dashboard = asyncHandler(async (req, res) => {
  const studentId = req.user.studentId;
  const settings = await settingsModel.getAll();
  const maxRenewals = Number(settings.max_renewals_per_book);
  const dueSoonDays = Number(settings.due_soon_threshold_days);

  const issues = await issueModel.findActiveByStudent(studentId);
  const serialized = issues.map((i) => serializeIssue(i, maxRenewals));

  const overdueCount = serialized.filter((i) => i.status === 'overdue').length;
  const dueSoonCount = serialized.filter((i) => i.status === 'due_soon').length;
  const activeFines = await fineModel.totalUnpaidByStudent(studentId);

  ok(res, {
    stats: {
      issuedBooks: serialized.length,
      dueSoon: dueSoonCount,
      overdue: overdueCount,
      activeFines,
      maxBooksAllowed: Number(settings.max_books_per_student),
    },
    books: serialized,
  });
});

// GET /api/student/books
const myBooks = asyncHandler(async (req, res) => {
  const settings = await settingsModel.getAll();
  const maxRenewals = Number(settings.max_renewals_per_book);
  const issues = await issueModel.findActiveByStudent(req.user.studentId);
  ok(res, { books: issues.map((i) => serializeIssue(i, maxRenewals)) });
});

// GET /api/student/history
const history = asyncHandler(async (req, res) => {
  const rows = await issueModel.findHistoryByStudent(req.user.studentId, { limit: 100 });
  ok(res, {
    history: rows.map((i) => ({
      issueId: i.id,
      title: i.title,
      bookCode: i.book_code,
      issueDate: i.issue_date,
      dueDate: i.due_date,
      returnedDate: i.returned_date,
      renewalCount: i.renewal_count,
      status: i.status,
    })),
  });
});

// GET /api/student/renewals
const renewalHistory = asyncHandler(async (req, res) => {
  const rows = await renewalModel.findByStudent(req.user.studentId);
  ok(res, {
    renewals: rows.map((r) => ({
      id: r.id,
      title: r.title,
      bookCode: r.book_code,
      previousDueDate: r.previous_due_date,
      newDueDate: r.new_due_date,
      renewalNumber: r.renewal_number,
      method: r.method,
      createdAt: r.created_at,
    })),
  });
});

// GET /api/student/profile
const getProfile = asyncHandler(async (req, res) => {
  const student = await studentModel.findByUserId(req.user.userId);
  if (!student) throw new ApiError(404, 'Student profile not found.', 'NOT_FOUND');
  ok(res, {
    profile: {
      name: student.name,
      email: student.email,
      studentId: student.student_id,
      course: student.course,
      semester: student.semester,
      department: student.department,
      phone: student.phone,
      accountStatus: student.account_status,
    },
  });
});

// PUT /api/student/profile
const updateProfile = asyncHandler(async (req, res) => {
  const { name } = req.body;
  if (name !== undefined) {
    if (!isNonEmptyString(name, 150)) throw new ApiError(400, 'Please enter a valid name.', 'VALIDATION');
    await userModel.updateProfile(req.user.userId, { name });
  }
  const student = await studentModel.findByUserId(req.user.userId);
  ok(res, { profile: student });
});

module.exports = { dashboard, myBooks, history, renewalHistory, getProfile, updateProfile, serializeIssue };
