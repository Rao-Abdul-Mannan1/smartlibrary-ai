// backend/controllers/authController.js
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');

const env = require('../config/env');
const { pool, withTransaction } = require('../config/db');
const userModel = require('../models/userModel');
const studentModel = require('../models/studentModel');
const verificationModel = require('../models/verificationModel');
const emailService = require('../services/emailService');
const auditService = require('../services/auditService');
const { isCollegeEmail, isStrongPassword, isNonEmptyString } = require('../utils/validators');
const { ApiError, ok } = require('../utils/apiResponse');
const asyncHandler = require('../utils/asyncHandler');

const OTP_TTL_MINUTES = 15;

function generateOtp() {
  return String(crypto.randomInt(100000, 999999)); // 6-digit code
}

function signToken(payload) {
  return jwt.sign(payload, env.JWT_SECRET, { expiresIn: env.JWT_EXPIRES_IN });
}

async function issueOtp(userId, purpose) {
  const code = generateOtp();
  const codeHash = await bcrypt.hash(code, env.BCRYPT_SALT_ROUNDS);
  const expiresAt = new Date(Date.now() + OTP_TTL_MINUTES * 60 * 1000);
  await verificationModel.create(null, { userId, codeHash, purpose, expiresAt });
  return code;
}

// POST /api/auth/register
const register = asyncHandler(async (req, res) => {
  const { name, email, studentId, password, confirmPassword, course, semester, department } = req.body;

  if (!isNonEmptyString(name, 150)) throw new ApiError(400, 'Please enter your full name.', 'VALIDATION');
  if (!isNonEmptyString(studentId, 50)) throw new ApiError(400, 'Please enter your student ID.', 'VALIDATION');
  if (!isCollegeEmail(email)) {
    throw new ApiError(400, 'Please use your official college email address.', 'INVALID_DOMAIN');
  }
  if (password !== confirmPassword) throw new ApiError(400, 'Passwords do not match.', 'VALIDATION');
  if (!isStrongPassword(password)) {
    throw new ApiError(400, 'Password must be at least 8 characters and include a letter and a number.', 'WEAK_PASSWORD');
  }

  const existing = await userModel.findByEmail(email.toLowerCase());
  if (existing) throw new ApiError(409, 'An account with this email already exists.', 'DUPLICATE');

  const passwordHash = await bcrypt.hash(password, env.BCRYPT_SALT_ROUNDS);

  const userId = await withTransaction(async (conn) => {
    const uid = await userModel.create(conn, { name, email: email.toLowerCase(), passwordHash, role: 'student' });
    await studentModel.create(conn, { userId: uid, studentId, course, semester, department });
    return uid;
  });

  const code = await issueOtp(userId, 'verify_email');
  const emailResult = await emailService.sendOtpEmail(email, code, 'verify_email');
  await auditService.log(userId, 'register', `user:${userId}`);

  ok(res, {
    message: 'Account created. Please check your email for a verification code.',
    userId,
    devOtpPreview: env.NODE_ENV === 'development' ? emailResult.devPreview : undefined,
  }, 201);
});

// POST /api/auth/verify-email
const verifyEmail = asyncHandler(async (req, res) => {
  const { email, code } = req.body;
  if (!isNonEmptyString(email) || !isNonEmptyString(code, 10)) {
    throw new ApiError(400, 'Email and verification code are required.', 'VALIDATION');
  }

  const user = await userModel.findByEmail(email.toLowerCase());
  if (!user) throw new ApiError(404, 'No account found for this email.', 'NOT_FOUND');
  if (user.email_verified) return ok(res, { message: 'Email already verified. You can log in.' });

  const record = await verificationModel.findActive(user.id, 'verify_email');
  if (!record) throw new ApiError(400, 'No active verification code. Please request a new one.', 'EXPIRED');

  const matches = await bcrypt.compare(code, record.code_hash);
  if (!matches) throw new ApiError(400, 'Incorrect verification code.', 'INVALID_CODE');

  await verificationModel.consume(record.id);
  await userModel.markEmailVerified(user.id);
  await auditService.log(user.id, 'email_verified', `user:${user.id}`);

  ok(res, { message: 'Email verified successfully. You can now log in.' });
});

// POST /api/auth/resend-otp
const resendOtp = asyncHandler(async (req, res) => {
  const { email, purpose = 'verify_email' } = req.body;
  const user = await userModel.findByEmail((email || '').toLowerCase());
  if (!user) throw new ApiError(404, 'No account found for this email.', 'NOT_FOUND');
  if (purpose === 'verify_email' && user.email_verified) {
    return ok(res, { message: 'Email already verified. You can log in.' });
  }
  const code = await issueOtp(user.id, purpose);
  const emailResult = await emailService.sendOtpEmail(email, code, purpose);
  ok(res, {
    message: 'A new code has been sent to your email.',
    devOtpPreview: env.NODE_ENV === 'development' ? emailResult.devPreview : undefined,
  });
});

// POST /api/auth/login  (shared by students and admins — role decides where the frontend redirects)
const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  if (!isNonEmptyString(email) || !isNonEmptyString(password)) {
    throw new ApiError(400, 'Email and password are required.', 'VALIDATION');
  }

  const user = await userModel.findByEmail(email.toLowerCase());
  if (!user) throw new ApiError(401, 'Invalid email or password.', 'INVALID_CREDENTIALS');

  const matches = await bcrypt.compare(password, user.password_hash);
  if (!matches) throw new ApiError(401, 'Invalid email or password.', 'INVALID_CREDENTIALS');

  if (user.status === 'blocked') throw new ApiError(403, 'Your account has been blocked. Please contact the library.', 'BLOCKED');
  if (user.status === 'deactivated') throw new ApiError(403, 'Your account has been deactivated.', 'DEACTIVATED');
  if (!user.email_verified) throw new ApiError(403, 'Please verify your email before logging in.', 'NOT_VERIFIED');

  const payload = { userId: user.id, role: user.role, name: user.name, email: user.email };

  if (user.role === 'student') {
    const student = await studentModel.findByUserId(user.id);
    payload.studentId = student.id;
  } else {
    const [rows] = await pool.execute('SELECT id FROM admins WHERE user_id = ? LIMIT 1', [user.id]);
    payload.adminId = rows[0] ? rows[0].id : null;
  }

  const token = signToken(payload);
  await auditService.log(user.id, 'login', `user:${user.id}`);

  ok(res, {
    token,
    user: { id: user.id, name: user.name, email: user.email, role: user.role },
  });
});

// POST /api/auth/forgot-password
const forgotPassword = asyncHandler(async (req, res) => {
  const { email } = req.body;
  const user = await userModel.findByEmail((email || '').toLowerCase());
  // Always respond the same way whether or not the account exists, to avoid leaking which emails are registered.
  if (user) {
    const code = await issueOtp(user.id, 'reset_password');
    const emailResult = await emailService.sendOtpEmail(email, code, 'reset_password');
    return ok(res, {
      message: 'If an account exists for that email, a reset code has been sent.',
      devOtpPreview: env.NODE_ENV === 'development' ? emailResult.devPreview : undefined,
    });
  }
  ok(res, { message: 'If an account exists for that email, a reset code has been sent.' });
});

// POST /api/auth/reset-password
const resetPassword = asyncHandler(async (req, res) => {
  const { email, code, newPassword, confirmPassword } = req.body;
  if (newPassword !== confirmPassword) throw new ApiError(400, 'Passwords do not match.', 'VALIDATION');
  if (!isStrongPassword(newPassword)) {
    throw new ApiError(400, 'Password must be at least 8 characters and include a letter and a number.', 'WEAK_PASSWORD');
  }

  const user = await userModel.findByEmail((email || '').toLowerCase());
  if (!user) throw new ApiError(404, 'No account found for this email.', 'NOT_FOUND');

  const record = await verificationModel.findActive(user.id, 'reset_password');
  if (!record) throw new ApiError(400, 'No active reset code. Please request a new one.', 'EXPIRED');

  const matches = await bcrypt.compare(code, record.code_hash);
  if (!matches) throw new ApiError(400, 'Incorrect reset code.', 'INVALID_CODE');

  await verificationModel.consume(record.id);
  const passwordHash = await bcrypt.hash(newPassword, env.BCRYPT_SALT_ROUNDS);
  await userModel.updatePassword(user.id, passwordHash);
  await auditService.log(user.id, 'password_reset', `user:${user.id}`);

  ok(res, { message: 'Password reset successfully. You can now log in.' });
});

// GET /api/auth/me
const me = asyncHandler(async (req, res) => {
  const user = await userModel.findById(req.user.userId);
  if (!user) throw new ApiError(404, 'User not found.', 'NOT_FOUND');
  const base = { id: user.id, name: user.name, email: user.email, role: user.role, status: user.status };
  if (user.role === 'student') {
    const student = await studentModel.findByUserId(user.id);
    return ok(res, { ...base, studentProfile: student });
  }
  ok(res, base);
});

module.exports = { register, verifyEmail, resendOtp, login, forgotPassword, resetPassword, me };
