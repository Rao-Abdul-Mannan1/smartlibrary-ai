// backend/controllers/bookController.js
const path = require('path');
const bookModel = require('../models/bookModel');
const issueModel = require('../models/issueModel');
const qrService = require('../services/qrService');
const auditService = require('../services/auditService');
const { ApiError, ok } = require('../utils/apiResponse');
const asyncHandler = require('../utils/asyncHandler');
const { isNonEmptyString } = require('../utils/validators');

function serializeBook(b) {
  if (!b) return null;
  return {
    id: b.id,
    bookId: b.book_id,
    isbn: b.isbn,
    title: b.title,
    author: b.author,
    publisher: b.publisher,
    edition: b.edition,
    category: b.category_name,
    categoryId: b.category_id,
    description: b.description,
    coverImage: b.cover_image,
    qrImage: b.qr_image,
    shelfNumber: b.shelf_number,
    quantity: b.quantity,
    availableQuantity: b.available_quantity,
    isActive: !!b.is_active,
  };
}

// GET /api/books  (search + filters; also used by the public/student catalog page)
const listBooks = asyncHandler(async (req, res) => {
  const { q, category, availability, author, limit, offset } = req.query;
  const books = await bookModel.search({
    q, category, availability, author,
    limit: Math.min(parseInt(limit, 10) || 30, 100),
    offset: parseInt(offset, 10) || 0,
  });
  ok(res, { books: books.map(serializeBook) });
});

// GET /api/books/categories
const listCategories = asyncHandler(async (req, res) => {
  const categories = await bookModel.listCategories();
  ok(res, { categories });
});

// GET /api/books/:id
const getBook = asyncHandler(async (req, res) => {
  const book = await bookModel.findById(req.params.id);
  if (!book) throw new ApiError(404, 'Book not found.', 'NOT_FOUND');
  ok(res, { book: serializeBook(book) });
});

// POST /api/books/scan  { payload: "BOOK_ID=BK-1025" }  — used by the camera scanner and manual entry fallback
const scanBook = asyncHandler(async (req, res) => {
  const { payload } = req.body;
  const bookId = qrService.parseScannedPayload(payload);
  if (!bookId) {
    throw new ApiError(400, 'Book could not be identified. Please scan the QR/barcode again.', 'UNRECOGNIZED_CODE');
  }
  const book = await bookModel.findByBookId(bookId);
  if (!book) {
    throw new ApiError(404, 'Book could not be identified. Please scan the QR/barcode again.', 'NOT_FOUND');
  }

  const result = { book: serializeBook(book) };

  // If the scanning student has this book issued, include their issue + eligibility context
  // so the frontend can render the full "Show Book Details -> Check Eligibility" screen in one call.
  if (req.user && req.user.role === 'student') {
    const issue = await issueModel.findActiveByStudentAndBook(req.user.studentId, book.id);
    result.myIssue = issue ? {
      issueId: issue.id,
      issueDate: issue.issue_date,
      dueDate: issue.due_date,
      renewalCount: issue.renewal_count,
      status: issue.status,
    } : null;
  }

  ok(res, result);
});

// GET /api/books/:id/qr  — download the QR PNG
const downloadQr = asyncHandler(async (req, res) => {
  const book = await bookModel.findById(req.params.id);
  if (!book) throw new ApiError(404, 'Book not found.', 'NOT_FOUND');
  if (!book.qr_image) throw new ApiError(404, 'QR code not generated for this book yet.', 'NOT_FOUND');
  const filePath = path.join(__dirname, '..', '..', book.qr_image.replace(/^\//, ''));
  res.download(filePath, `${book.book_id}-qr.png`);
});

// ---- Admin ----

// POST /api/books  (admin: add book)
const createBook = asyncHandler(async (req, res) => {
  const { isbn, title, author, publisher, edition, category, description, shelfNumber, quantity } = req.body;
  if (!isNonEmptyString(title, 255)) throw new ApiError(400, 'Title is required.', 'VALIDATION');
  if (!isNonEmptyString(author, 255)) throw new ApiError(400, 'Author is required.', 'VALIDATION');
  const qty = Math.max(1, parseInt(quantity, 10) || 1);

  let categoryId = null;
  if (isNonEmptyString(category, 100)) {
    categoryId = await bookModel.findOrCreateCategory(null, category.trim());
  }

  const bookId = await bookModel.nextBookId();
  const id = await bookModel.create({
    bookId, isbn, title, author, publisher, edition, categoryId,
    description, coverImage: null, shelfNumber, quantity: qty,
  });

  const qrPath = await qrService.generateForBook(bookId);
  await bookModel.setQrImage(id, qrPath);

  await auditService.log(req.user.userId, 'book_added', `book:${id}`, { bookId, title });

  const book = await bookModel.findById(id);
  ok(res, { book: serializeBook(book) }, 201);
});

// PUT /api/books/:id  (admin: edit book)
const updateBook = asyncHandler(async (req, res) => {
  const book = await bookModel.findById(req.params.id);
  if (!book) throw new ApiError(404, 'Book not found.', 'NOT_FOUND');

  const fields = {};
  const direct = ['isbn', 'title', 'author', 'publisher', 'edition', 'description', 'shelf_number'];
  const bodyKeyMap = { shelf_number: 'shelfNumber' };
  for (const key of direct) {
    const bodyKey = bodyKeyMap[key] || key;
    if (req.body[bodyKey] !== undefined) fields[key] = req.body[bodyKey];
  }
  if (req.body.category !== undefined && isNonEmptyString(req.body.category, 100)) {
    fields.category_id = await bookModel.findOrCreateCategory(null, req.body.category.trim());
  }
  if (req.body.quantity !== undefined) {
    const newQty = parseInt(req.body.quantity, 10);
    if (Number.isFinite(newQty) && newQty >= 0) {
      // Keep available_quantity consistent: shift it by the same delta as quantity.
      const delta = newQty - book.quantity;
      fields.quantity = newQty;
      fields.available_quantity = Math.max(0, book.available_quantity + delta);
    }
  }

  await bookModel.update(req.params.id, fields);
  await auditService.log(req.user.userId, 'book_edited', `book:${req.params.id}`, fields);

  const updated = await bookModel.findById(req.params.id);
  ok(res, { book: serializeBook(updated) });
});

// DELETE /api/books/:id  (admin: deactivate, not a hard delete — preserves issue history integrity)
const deleteBook = asyncHandler(async (req, res) => {
  const book = await bookModel.findById(req.params.id);
  if (!book) throw new ApiError(404, 'Book not found.', 'NOT_FOUND');
  await bookModel.softDelete(req.params.id);
  await auditService.log(req.user.userId, 'book_deactivated', `book:${req.params.id}`);
  ok(res, { message: 'Book deactivated.' });
});

// PUT /api/books/:id/cover  (admin: upload/replace cover image, multipart field name "cover")
const uploadCover = asyncHandler(async (req, res) => {
  const book = await bookModel.findById(req.params.id);
  if (!book) throw new ApiError(404, 'Book not found.', 'NOT_FOUND');
  if (!req.file) throw new ApiError(400, 'No image file uploaded.', 'VALIDATION');

  const relativePath = `/uploads/covers/${req.file.filename}`;
  await bookModel.update(req.params.id, { cover_image: relativePath });
  await auditService.log(req.user.userId, 'book_edited', `book:${req.params.id}`, { coverImage: relativePath });

  const updated = await bookModel.findById(req.params.id);
  ok(res, { book: serializeBook(updated) });
});

module.exports = {
  listBooks, listCategories, getBook, scanBook, downloadQr,
  createBook, updateBook, deleteBook, uploadCover, serializeBook,
};
