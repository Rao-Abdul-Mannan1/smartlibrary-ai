// backend/controllers/fineController.js
const fineModel = require('../models/fineModel');
const auditService = require('../services/auditService');
const { ApiError, ok } = require('../utils/apiResponse');
const asyncHandler = require('../utils/asyncHandler');

// GET /api/student/fines
const myFines = asyncHandler(async (req, res) => {
  const fines = await fineModel.findByStudent(req.user.studentId);
  const totalUnpaid = await fineModel.totalUnpaidByStudent(req.user.studentId);
  ok(res, {
    totalUnpaid,
    fines: fines.map((f) => ({
      id: f.id, book: f.title, bookCode: f.book_code,
      amount: Number(f.amount), reason: f.reason, status: f.status,
      createdAt: f.created_at, paidAt: f.paid_at,
    })),
  });
});

// GET /api/fines  (admin)
const listFines = asyncHandler(async (req, res) => {
  const { status, limit, offset } = req.query;
  const fines = await fineModel.findAll({
    status, limit: Math.min(parseInt(limit, 10) || 100, 200), offset: parseInt(offset, 10) || 0,
  });
  const totalCollected = await fineModel.totalCollected();
  const totalOutstanding = await fineModel.totalOutstanding();
  ok(res, {
    totalCollected, totalOutstanding,
    fines: fines.map((f) => ({
      id: f.id, student: f.student_name, studentCode: f.student_code,
      book: f.title, amount: Number(f.amount), reason: f.reason,
      status: f.status, createdAt: f.created_at, paidAt: f.paid_at,
    })),
  });
});

// PUT /api/fines/:id  (admin: mark paid/waived)  Body: { status: 'paid'|'waived'|'unpaid' }
const updateFineStatus = asyncHandler(async (req, res) => {
  const { status } = req.body;
  if (!['paid', 'waived', 'unpaid'].includes(status)) {
    throw new ApiError(400, 'Status must be paid, waived, or unpaid.', 'VALIDATION');
  }
  const fine = await fineModel.findById(req.params.id);
  if (!fine) throw new ApiError(404, 'Fine not found.', 'NOT_FOUND');

  await fineModel.updateStatus(req.params.id, status);
  await auditService.log(req.user.userId, 'fine_updated', `fine:${req.params.id}`, { status });
  ok(res, { message: `Fine marked as ${status}.` });
});

module.exports = { myFines, listFines, updateFineStatus };
