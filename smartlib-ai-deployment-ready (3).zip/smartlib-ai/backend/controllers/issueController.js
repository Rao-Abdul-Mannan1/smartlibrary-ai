// backend/controllers/issueController.js
const { withTransaction } = require('../config/db');
const bookModel = require('../models/bookModel');
const issueModel = require('../models/issueModel');
const studentModel = require('../models/studentModel');
const reservationModel = require('../models/reservationModel');
const notificationModel = require('../models/notificationModel');
const settingsModel = require('../models/settingsModel');
const fineService = require('../services/fineService');
const qrService = require('../services/qrService');
const auditService = require('../services/auditService');
const dateUtils = require('../utils/dateUtils');
const { ApiError, ok } = require('../utils/apiResponse');
const asyncHandler = require('../utils/asyncHandler');

// POST /api/issues  (admin: issue a book to a student)
// Body: { studentId, bookId } OR { studentId, scannedPayload }
const issueBook = asyncHandler(async (req, res) => {
  const { studentId, bookId, scannedPayload, dueDate: customDueDate } = req.body;
  if (!studentId) throw new ApiError(400, 'studentId is required.', 'VALIDATION');

  let resolvedBookId = bookId;
  if (!resolvedBookId && scannedPayload) {
    const code = qrService.parseScannedPayload(scannedPayload);
    if (!code) throw new ApiError(400, 'Book could not be identified. Please scan the QR/barcode again.', 'UNRECOGNIZED_CODE');
    const book = await bookModel.findByBookId(code);
    if (!book) throw new ApiError(404, 'Book could not be identified. Please scan the QR/barcode again.', 'NOT_FOUND');
    resolvedBookId = book.id;
  }
  if (!resolvedBookId) throw new ApiError(400, 'bookId or scannedPayload is required.', 'VALIDATION');

  const result = await withTransaction(async (conn) => {
    const [bookRows] = await conn.execute('SELECT * FROM books WHERE id = ? FOR UPDATE', [resolvedBookId]);
    const book = bookRows[0];
    if (!book || !book.is_active) throw new ApiError(404, 'Book not found.', 'NOT_FOUND');
    if (book.available_quantity <= 0) {
      throw new ApiError(400, 'No available copies of this book right now. Consider reserving it instead.', 'UNAVAILABLE');
    }

    const student = await studentModel.findById(studentId);
    if (!student) throw new ApiError(404, 'Student not found.', 'NOT_FOUND');
    if (student.account_status === 'blocked') {
      throw new ApiError(400, "This student's account is blocked from borrowing.", 'ACCOUNT_BLOCKED');
    }

    const settings = await settingsModel.getAll();
    const maxBooks = Number(settings.max_books_per_student);
    const activeCount = (await issueModel.findActiveByStudent(studentId)).length;
    if (activeCount >= maxBooks) {
      throw new ApiError(400, `This student has reached the maximum of ${maxBooks} issued books.`, 'MAX_BOOKS_REACHED');
    }

    const alreadyHas = await issueModel.findActiveByStudentAndBook(studentId, resolvedBookId);
    if (alreadyHas) throw new ApiError(400, 'This student already has this book issued.', 'ALREADY_ISSUED');

    const issueDate = dateUtils.todayISO();
    const dueDate = customDueDate || dateUtils.addDays(issueDate, Number(settings.loan_period_days));

    const issueId = await issueModel.create(conn, {
      studentId, bookId: resolvedBookId, issueDate, dueDate, issuedBy: req.user.userId,
    });
    await bookModel.adjustAvailability(conn, resolvedBookId, -1);
    await notificationModel.create(conn, {
      userId: student.user_id,
      type: 'system',
      title: 'Book issued',
      message: `"${book.title}" has been issued to you. Due date: ${dateUtils.formatDisplay(dueDate)}.`,
    });

    return { issueId, issueDate, dueDate, book, student };
  });

  await auditService.log(req.user.userId, 'book_issued', `issue:${result.issueId}`, {
    bookId: resolvedBookId, studentId,
  });

  ok(res, {
    message: 'Book issued successfully.',
    issueId: result.issueId,
    issueDate: result.issueDate,
    dueDate: result.dueDate,
    book: { id: result.book.id, bookId: result.book.book_id, title: result.book.title },
  }, 201);
});

// POST /api/issues/return  (admin: return a book — scan QR or search Book ID / issue ID)
const returnBook = asyncHandler(async (req, res) => {
  const { issueId, scannedPayload } = req.body;

  const result = await withTransaction(async (conn) => {
    let resolvedIssueId = issueId;

    if (!resolvedIssueId && scannedPayload) {
      const code = qrService.parseScannedPayload(scannedPayload);
      if (!code) throw new ApiError(400, 'Book could not be identified. Please scan the QR/barcode again.', 'UNRECOGNIZED_CODE');
      const [bookRows] = await conn.execute('SELECT * FROM books WHERE book_id = ? LIMIT 1', [code]);
      const book = bookRows[0];
      if (!book) throw new ApiError(404, 'Book could not be identified.', 'NOT_FOUND');
      const [issueRows] = await conn.execute(
        `SELECT * FROM issues WHERE book_id = ? AND status IN ('active','overdue') ORDER BY issue_date ASC LIMIT 1`,
        [book.id]
      );
      if (!issueRows[0]) throw new ApiError(404, 'No active issue found for this book.', 'NOT_FOUND');
      resolvedIssueId = issueRows[0].id;
    }
    if (!resolvedIssueId) throw new ApiError(400, 'issueId or scannedPayload is required.', 'VALIDATION');

    const [rows] = await conn.execute(
      `SELECT i.*, s.id AS student_row_id, u.id AS user_id
       FROM issues i JOIN students s ON s.id = i.student_id JOIN users u ON u.id = s.user_id
       WHERE i.id = ? FOR UPDATE`,
      [resolvedIssueId]
    );
    const issue = rows[0];
    if (!issue) throw new ApiError(404, 'Issue record not found.', 'NOT_FOUND');
    if (issue.status === 'returned') throw new ApiError(400, 'This book has already been returned.', 'ALREADY_RETURNED');

    const settings = await settingsModel.getAll();
    const returnDate = dateUtils.todayISO();

    const fine = await fineService.applyFineIfOverdue(conn, {
      studentId: issue.student_id,
      issueId: issue.id,
      dueDate: issue.due_date,
      returnDate,
      ratePerDay: Number(settings.fine_per_day),
    });

    await issueModel.markReturned(conn, issue.id, returnDate, req.user.userId);
    await bookModel.adjustAvailability(conn, issue.book_id, 1);

    const book = await bookModel.findById(issue.book_id);

    if (fine) {
      await notificationModel.create(conn, {
        userId: issue.user_id, type: 'fine',
        title: 'Fine applied',
        message: `A fine of \u20b9${fine.amount} was applied for returning "${book.title}" ${fine.overdueDays} day(s) late.`,
      });
    }

    // Notify the next student in the reservation queue, if any, that the book is now available.
    const nextReservation = await reservationModel.nextInQueue(conn, issue.book_id);
    if (nextReservation) {
      await reservationModel.markNotified(conn, nextReservation.id);
      const [resStudentRows] = await conn.execute(
        `SELECT u.id AS user_id FROM students s JOIN users u ON u.id = s.user_id WHERE s.id = ?`,
        [nextReservation.student_id]
      );
      if (resStudentRows[0]) {
        await notificationModel.create(conn, {
          userId: resStudentRows[0].user_id, type: 'reservation',
          title: 'Reserved book available',
          message: `"${book.title}" that you reserved is now available at the library desk.`,
        });
      }
    }

    return { issue, book, fine, returnDate };
  });

  await auditService.log(req.user.userId, 'book_returned', `issue:${result.issue.id}`, {
    fineApplied: result.fine ? result.fine.amount : 0,
  });

  ok(res, {
    message: 'Book returned successfully.',
    issueId: result.issue.id,
    book: { id: result.book.id, bookId: result.book.book_id, title: result.book.title },
    returnDate: result.returnDate,
    overdueDays: result.fine ? result.fine.overdueDays : 0,
    fineAmount: result.fine ? result.fine.amount : 0,
  });
});

// GET /api/issues/overdue  (admin: overdue list)
const overdueList = asyncHandler(async (req, res) => {
  const rows = await issueModel.overdueList({ limit: 200 });
  ok(res, {
    overdue: rows.map((i) => ({
      issueId: i.id,
      student: i.student_name,
      studentCode: i.student_code,
      book: i.title,
      bookCode: i.book_code,
      dueDate: i.due_date,
      daysOverdue: Math.abs(dateUtils.daysBetween(dateUtils.todayISO(), i.due_date)),
    })),
  });
});

module.exports = { issueBook, returnBook, overdueList };
