// backend/controllers/aiController.js
const aiService = require('../services/aiService');
const aiModel = require('../models/aiModel');
const { ApiError, ok } = require('../utils/apiResponse');
const asyncHandler = require('../utils/asyncHandler');
const { isNonEmptyString } = require('../utils/validators');

// POST /api/ai/chat  { message, conversationId? }
const chat = asyncHandler(async (req, res) => {
  const { message, conversationId } = req.body;
  if (!isNonEmptyString(message, 1000)) {
    throw new ApiError(400, 'Please enter a message.', 'VALIDATION');
  }

  const result = await aiService.chat({
    studentId: req.user.studentId,
    conversationId: conversationId || null,
    message: message.trim(),
  });

  ok(res, result);
});

// GET /api/ai/history?conversationId=
const history = asyncHandler(async (req, res) => {
  const { conversationId } = req.query;
  let conv = null;
  if (conversationId) {
    conv = await aiModel.findConversation(conversationId, req.user.studentId);
  } else {
    conv = await aiModel.latestConversation(req.user.studentId);
  }
  if (!conv) return ok(res, { conversationId: null, messages: [] });

  const messages = await aiModel.getMessages(conv.id, 50);
  ok(res, {
    conversationId: conv.id,
    messages: messages
      .filter((m) => m.role !== 'tool')
      .map((m) => ({ role: m.role, content: m.content, createdAt: m.created_at })),
  });
});

// GET /api/ai/status — lets the frontend show "Full AI mode" vs "Basic mode"
const status = asyncHandler(async (req, res) => {
  ok(res, { fullModeAvailable: aiService.isFullModeAvailable() });
});

module.exports = { chat, history, status };
