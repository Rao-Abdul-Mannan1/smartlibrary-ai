// backend/controllers/settingsController.js
const settingsModel = require('../models/settingsModel');
const auditService = require('../services/auditService');
const { ok } = require('../utils/apiResponse');
const asyncHandler = require('../utils/asyncHandler');

// GET /api/settings — also used by the public "Library Rules" page (spec section 29)
const getSettings = asyncHandler(async (req, res) => {
  const settings = await settingsModel.getAll();
  ok(res, { settings });
});

// PUT /api/settings  (admin only)
const updateSettings = asyncHandler(async (req, res) => {
  const allowedKeys = Object.keys(settingsModel.DEFAULTS);
  const updates = {};
  for (const key of allowedKeys) {
    if (req.body[key] !== undefined) updates[key] = req.body[key];
  }
  await settingsModel.upsertMany(updates);
  await auditService.log(req.user.userId, 'settings_updated', 'library_settings', updates);
  const settings = await settingsModel.getAll();
  ok(res, { message: 'Library settings updated.', settings });
});

module.exports = { getSettings, updateSettings };
