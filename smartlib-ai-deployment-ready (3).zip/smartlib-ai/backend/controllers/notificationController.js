// backend/controllers/notificationController.js
const notificationModel = require('../models/notificationModel');
const { ok } = require('../utils/apiResponse');
const asyncHandler = require('../utils/asyncHandler');

// GET /api/notifications
const list = asyncHandler(async (req, res) => {
  const { limit, offset } = req.query;
  const notifications = await notificationModel.findByUser(req.user.userId, {
    limit: Math.min(parseInt(limit, 10) || 30, 100),
    offset: parseInt(offset, 10) || 0,
  });
  const unread = await notificationModel.unreadCount(req.user.userId);
  ok(res, { notifications, unread });
});

// PUT /api/notifications/:id/read
const markRead = asyncHandler(async (req, res) => {
  await notificationModel.markRead(req.params.id, req.user.userId);
  ok(res, { message: 'Marked as read.' });
});

// PUT /api/notifications/read-all
const markAllRead = asyncHandler(async (req, res) => {
  await notificationModel.markAllRead(req.user.userId);
  ok(res, { message: 'All notifications marked as read.' });
});

module.exports = { list, markRead, markAllRead };
