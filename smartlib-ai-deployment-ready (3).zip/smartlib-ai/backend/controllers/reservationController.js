// backend/controllers/reservationController.js
const bookModel = require('../models/bookModel');
const reservationModel = require('../models/reservationModel');
const auditService = require('../services/auditService');
const { ApiError, ok } = require('../utils/apiResponse');
const asyncHandler = require('../utils/asyncHandler');

// POST /api/reservations  { bookId }
const createReservation = asyncHandler(async (req, res) => {
  const { bookId } = req.body;
  if (!bookId) throw new ApiError(400, 'bookId is required.', 'VALIDATION');

  const book = await bookModel.findById(bookId);
  if (!book) throw new ApiError(404, 'Book not found.', 'NOT_FOUND');
  if (book.available_quantity > 0) {
    throw new ApiError(400, 'This book is currently available — no need to reserve it, you can borrow it directly.', 'BOOK_AVAILABLE');
  }

  const existing = await reservationModel.findActiveByStudentAndBook(req.user.studentId, bookId);
  if (existing) throw new ApiError(409, 'You already have an active reservation for this book.', 'DUPLICATE');

  const id = await reservationModel.create(req.user.studentId, bookId);
  await auditService.log(req.user.userId, 'reservation_created', `reservation:${id}`, { bookId });

  ok(res, { message: 'Book reserved. You will be notified when it becomes available.', reservationId: id }, 201);
});

// GET /api/student/reservations
const myReservations = asyncHandler(async (req, res) => {
  const rows = await reservationModel.findByStudent(req.user.studentId);
  ok(res, {
    reservations: rows.map((r) => ({
      id: r.id, book: r.title, bookCode: r.book_code, author: r.author,
      status: r.status, reservedAt: r.reserved_at, fulfilledAt: r.fulfilled_at,
    })),
  });
});

// DELETE /api/reservations/:id
const cancelReservation = asyncHandler(async (req, res) => {
  const success = await reservationModel.cancel(req.params.id, req.user.studentId);
  if (!success) throw new ApiError(404, 'Active reservation not found.', 'NOT_FOUND');
  await auditService.log(req.user.userId, 'reservation_cancelled', `reservation:${req.params.id}`);
  ok(res, { message: 'Reservation cancelled.' });
});

// GET /api/reservations  (admin)
const listReservations = asyncHandler(async (req, res) => {
  const { status, limit, offset } = req.query;
  const rows = await reservationModel.findAll({
    status, limit: Math.min(parseInt(limit, 10) || 100, 200), offset: parseInt(offset, 10) || 0,
  });
  ok(res, {
    reservations: rows.map((r) => ({
      id: r.id, student: r.student_name, studentCode: r.student_code,
      book: r.title, bookCode: r.book_code, status: r.status,
      reservedAt: r.reserved_at, fulfilledAt: r.fulfilled_at,
    })),
  });
});

module.exports = { createReservation, myReservations, cancelReservation, listReservations };
