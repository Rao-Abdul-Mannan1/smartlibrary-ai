// backend/controllers/renewalController.js
const issueModel = require('../models/issueModel');
const renewalModel = require('../models/renewalModel');
const renewalService = require('../services/renewalService');
const auditService = require('../services/auditService');
const { ApiError, ok } = require('../utils/apiResponse');
const asyncHandler = require('../utils/asyncHandler');

// GET /api/renewals/check/:issueId — student: "is this book eligible for renewal?"
const checkEligibility = asyncHandler(async (req, res) => {
  const issue = await issueModel.findById(req.params.issueId);
  if (!issue) throw new ApiError(404, 'Issue record not found.', 'NOT_FOUND');
  if (issue.student_id !== req.user.studentId) {
    throw new ApiError(403, 'This book is not issued to your account.', 'FORBIDDEN');
  }
  const verdict = await renewalService.checkEligibility(issue);
  ok(res, {
    eligible: verdict.eligible,
    reason: verdict.reason,
    reasonCode: verdict.reasonCode,
    renewalsUsed: verdict.renewalsUsed,
    maxRenewals: verdict.maxRenewals,
  });
});

// POST /api/books/renew  { issueId } — student self-service renewal (spec section 7 flow)
const renewBook = asyncHandler(async (req, res) => {
  const { issueId } = req.body;
  if (!issueId) throw new ApiError(400, 'issueId is required.', 'VALIDATION');

  const result = await renewalService.renewBook({
    issueId,
    studentId: req.user.studentId,
    method: 'self_service',
  });

  await auditService.log(req.user.userId, 'renewal_performed', `issue:${issueId}`, {
    newDueDate: result.newDueDate,
  });

  ok(res, {
    message: 'Book renewed successfully.',
    ...result,
  });
});

// POST /api/renewals/admin  { issueId } — admin performs a renewal on the student's behalf
const adminRenewBook = asyncHandler(async (req, res) => {
  const { issueId } = req.body;
  if (!issueId) throw new ApiError(400, 'issueId is required.', 'VALIDATION');

  const issue = await issueModel.findById(issueId);
  if (!issue) throw new ApiError(404, 'Issue record not found.', 'NOT_FOUND');

  const result = await renewalService.renewBook({
    issueId,
    studentId: issue.student_id,
    method: 'admin',
    performedBy: req.user.userId,
  });

  await auditService.log(req.user.userId, 'renewal_performed_admin', `issue:${issueId}`, {
    newDueDate: result.newDueDate,
  });

  ok(res, { message: 'Renewal applied.', ...result });
});

// GET /api/renewals  — admin: renewal management list with filters
const listRenewals = asyncHandler(async (req, res) => {
  const { method, limit, offset } = req.query;
  const rows = await renewalModel.findAll({
    method,
    limit: Math.min(parseInt(limit, 10) || 100, 200),
    offset: parseInt(offset, 10) || 0,
  });
  ok(res, {
    renewals: rows.map((r) => ({
      id: r.id,
      student: r.student_name,
      studentCode: r.student_code,
      book: r.title,
      bookCode: r.book_code,
      previousDueDate: r.previous_due_date,
      newDueDate: r.new_due_date,
      renewalNumber: r.renewal_number,
      method: r.method,
      status: r.status,
      createdAt: r.created_at,
    })),
  });
});

module.exports = { checkEligibility, renewBook, adminRenewBook, listRenewals };
