// backend/controllers/reportController.js
const bookModel = require('../models/bookModel');
const issueModel = require('../models/issueModel');
const renewalModel = require('../models/renewalModel');
const fineModel = require('../models/fineModel');
const { pool } = require('../config/db');
const { ok } = require('../utils/apiResponse');
const asyncHandler = require('../utils/asyncHandler');

// GET /api/reports/charts — data for the 5 admin dashboard charts (spec section 45)
const charts = asyncHandler(async (req, res) => {
  const [monthlyIssues, monthlyReturns, monthlyRenewals, categoryDistribution, overdueBooks] = await Promise.all([
    issueModel.monthlyStats(6),
    issueModel.monthlyReturns(6),
    renewalModel.monthlyStats(6),
    bookModel.categoryDistribution(),
    issueModel.countOverdue(),
  ]);
  ok(res, { monthlyIssues, monthlyReturns, monthlyRenewals, categoryDistribution, overdueBooksCount: overdueBooks });
});

// GET /api/reports/most-borrowed?days=30
const mostBorrowed = asyncHandler(async (req, res) => {
  const { days } = req.query;
  const sinceDate = days ? new Date(Date.now() - parseInt(days, 10) * 86400000).toISOString().slice(0, 10) : null;
  const rows = await bookModel.mostBorrowed(10, sinceDate);
  ok(res, { books: rows });
});

// GET /api/reports/most-active-students
const mostActiveStudents = asyncHandler(async (req, res) => {
  const [rows] = await pool.execute(`
    SELECT s.id, s.student_id, u.name, COUNT(i.id) AS books_issued
    FROM students s JOIN users u ON u.id = s.user_id
    LEFT JOIN issues i ON i.student_id = s.id
    GROUP BY s.id ORDER BY books_issued DESC LIMIT 10
  `);
  ok(res, { students: rows });
});

// GET /api/reports/overdue
const overdueReport = asyncHandler(async (req, res) => {
  const rows = await issueModel.overdueList({ limit: 200 });
  ok(res, {
    overdue: rows.map((i) => ({
      student: i.student_name, book: i.title, dueDate: i.due_date, studentCode: i.student_code,
    })),
  });
});

// GET /api/reports/renewals
const renewalStats = asyncHandler(async (req, res) => {
  const stats = await renewalModel.monthlyStats(12);
  const total = await renewalModel.countTotal();
  ok(res, { monthly: stats, total });
});

// GET /api/reports/fines
const fineReport = asyncHandler(async (req, res) => {
  const collected = await fineModel.totalCollected();
  const outstanding = await fineModel.totalOutstanding();
  ok(res, { collected, outstanding, total: collected + outstanding });
});

// GET /api/reports/availability
const availabilityReport = asyncHandler(async (req, res) => {
  const total = await bookModel.countTotal();
  const available = await bookModel.countAvailable();
  const issued = await bookModel.countIssuedCopies();
  ok(res, { totalBooks: total, availableCopies: available, issuedCopies: issued });
});

module.exports = { charts, mostBorrowed, mostActiveStudents, overdueReport, renewalStats, fineReport, availabilityReport };
