// backend/scripts/seed.js
//
// Populates a freshly-created database (run schema.sql first) with
// realistic demo data: library settings, categories, a real textbook
// catalog with generated QR codes, one admin account, and three demo
// students in different states (a normal borrower, an overdue+fined
// borrower, and an empty-state borrower with a reservation) — chosen
// so the app's dashboards, fine management, reservation queue, and
// renewal history all have real, non-empty data to show on first run.
//
// Run:  npm run seed   (after: mysql -u root -p < database/schema.sql)

require('dotenv').config();
const bcrypt = require('bcryptjs');
const { pool } = require('../config/db');
const env = require('../config/env');
const qrService = require('../services/qrService');
const dateUtils = require('../utils/dateUtils');

const PASSWORD = 'Student@123';
const ADMIN_PASSWORD = 'Admin@123';

if (env.NODE_ENV === 'production' && process.env.ALLOW_DESTRUCTIVE_SEED !== 'true') {
  console.error('[seed] Refusing to run in production because this script truncates all application tables.');
  console.error('[seed] Set ALLOW_DESTRUCTIVE_SEED=true only for an intentional demo reset.');
  process.exit(1);
}

async function wipeExisting() {
  await pool.query('SET FOREIGN_KEY_CHECKS = 0');
  const tables = [
    'audit_logs', 'ai_messages', 'ai_conversations', 'notifications',
    'reservations', 'fines', 'renewals', 'issues', 'email_verifications',
    'books', 'categories', 'students', 'admins', 'users', 'library_settings',
  ];
  for (const t of tables) {
    await pool.query(`TRUNCATE TABLE ${t}`);
  }
  await pool.query('SET FOREIGN_KEY_CHECKS = 1');
  console.log('[seed] cleared existing data');
}

async function seedSettings() {
  const settingsModel = require('../models/settingsModel');
  await settingsModel.upsertMany(settingsModel.DEFAULTS);
  console.log('[seed] library_settings defaults inserted');
}

async function seedCategories(names) {
  const ids = {};
  for (const name of names) {
    const [result] = await pool.execute('INSERT INTO categories (name) VALUES (?)', [name]);
    ids[name] = result.insertId;
  }
  console.log(`[seed] ${names.length} categories inserted`);
  return ids;
}

async function seedBooks(catIds) {
  const catalog = [
    { title: 'Let Us C', author: 'Yashavant Kanetkar', isbn: '9789388511668', publisher: 'BPB Publications', edition: '17th', category: 'Programming', shelf: 'A1-01', quantity: 1 },
    { title: 'Data Structures Using C', author: 'Reema Thareja', isbn: '9780198099307', publisher: 'Oxford University Press', edition: '2nd', category: 'Data Structures & Algorithms', shelf: 'A2-05', quantity: 3 },
    { title: 'Database Management Systems', author: 'Abraham Silberschatz, Henry F. Korth, S. Sudarshan', isbn: '9780078022159', publisher: 'McGraw-Hill', edition: '7th', category: 'Database Systems', shelf: 'B1-02', quantity: 4 },
    { title: 'Operating System Concepts', author: 'Abraham Silberschatz, Peter B. Galvin, Greg Gagne', isbn: '9781118063330', publisher: 'Wiley', edition: '9th', category: 'Operating Systems', shelf: 'B2-03', quantity: 3 },
    { title: 'Computer Networks', author: 'Andrew S. Tanenbaum, David J. Wetherall', isbn: '9780132126953', publisher: 'Pearson', edition: '5th', category: 'Networking', shelf: 'C1-01', quantity: 3 },
    { title: 'Data Communications and Networking', author: 'Behrouz A. Forouzan', isbn: '9780073376226', publisher: 'McGraw-Hill', edition: '5th', category: 'Networking', shelf: 'C1-02', quantity: 2 },
    { title: 'Computer Networking: A Top-Down Approach', author: 'James F. Kurose, Keith W. Ross', isbn: '9780133594140', publisher: 'Pearson', edition: '7th', category: 'Networking', shelf: 'C1-03', quantity: 2 },
    { title: 'Web Design with HTML, CSS, JavaScript and jQuery', author: 'Jon Duckett', isbn: '9781118907443', publisher: 'Wiley', edition: '1st', category: 'Web Development', shelf: 'D1-01', quantity: 3 },
    { title: 'Artificial Intelligence: A Modern Approach', author: 'Stuart Russell, Peter Norvig', isbn: '9780136042594', publisher: 'Pearson', edition: '3rd', category: 'Artificial Intelligence', shelf: 'E1-01', quantity: 2 },
    { title: 'Machine Learning', author: 'Tom M. Mitchell', isbn: '9780070428072', publisher: 'McGraw-Hill', edition: '1st', category: 'Machine Learning', shelf: 'E2-01', quantity: 2 },
    { title: 'Cryptography and Network Security', author: 'William Stallings', isbn: '9780134444284', publisher: 'Pearson', edition: '7th', category: 'Cyber Security', shelf: 'F1-01', quantity: 2 },
    { title: 'Computer Organization and Architecture', author: 'William Stallings', isbn: '9780134997191', publisher: 'Pearson', edition: '11th', category: 'Computer Organization', shelf: 'F2-01', quantity: 3 },
  ];

  const books = {};
  let seq = 1000;
  for (const b of catalog) {
    seq += 1;
    const bookId = `BK-${seq}`;
    const [result] = await pool.execute(
      `INSERT INTO books (book_id, isbn, title, author, publisher, edition, category_id, description, shelf_number, quantity, available_quantity)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [bookId, b.isbn, b.title, b.author, b.publisher, b.edition, catIds[b.category],
       `${b.title} by ${b.author} (${b.edition} edition).`, b.shelf, b.quantity, b.quantity]
    );
    const qrPath = await qrService.generateForBook(bookId);
    await pool.execute('UPDATE books SET qr_image = ? WHERE id = ?', [qrPath, result.insertId]);
    books[b.title] = { id: result.insertId, bookId, quantity: b.quantity };
  }
  console.log(`[seed] ${catalog.length} books inserted with QR codes generated`);
  return books;
}

async function createUser({ name, email, role, studentFields }) {
  const passwordHash = await bcrypt.hash(role === 'admin' ? ADMIN_PASSWORD : PASSWORD, env.BCRYPT_SALT_ROUNDS);
  const [result] = await pool.execute(
    `INSERT INTO users (name, email, password_hash, role, status, email_verified) VALUES (?, ?, ?, ?, 'active', 1)`,
    [name, email, passwordHash, role]
  );
  const userId = result.insertId;
  if (role === 'admin') {
    await pool.execute('INSERT INTO admins (user_id, designation) VALUES (?, ?)', [userId, 'Chief Librarian']);
    return { userId };
  }
  const [srow] = await pool.execute(
    `INSERT INTO students (user_id, student_id, course, semester, department) VALUES (?, ?, ?, ?, ?)`,
    [userId, studentFields.studentId, studentFields.course, studentFields.semester, studentFields.department]
  );
  return { userId, studentRowId: srow.insertId };
}

// Issues a book directly with explicit dates (bypasses the live-issuing
// service on purpose — seed data represents *history*, not new transactions).
async function issueDirect({ studentRowId, book, daysAgoIssued, daysUntilDue, status = 'active', renewalCount = 0, returnedDaysAgo = null }) {
  const issueDate = dateUtils.addDays(dateUtils.todayISO(), -daysAgoIssued);
  const dueDate = dateUtils.addDays(dateUtils.todayISO(), daysUntilDue);
  const returnedDate = returnedDaysAgo !== null ? dateUtils.addDays(dateUtils.todayISO(), -returnedDaysAgo) : null;
  const finalStatus = returnedDate ? 'returned' : status;

  const [result] = await pool.execute(
    `INSERT INTO issues (student_id, book_id, issue_date, due_date, returned_date, renewal_count, status)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [studentRowId, book.id, issueDate, dueDate, returnedDate, renewalCount, finalStatus]
  );
  if (!returnedDate) {
    await pool.execute('UPDATE books SET available_quantity = available_quantity - 1 WHERE id = ?', [book.id]);
  }
  return { issueId: result.insertId, issueDate, dueDate, returnedDate };
}

async function addRenewal({ issueId, studentRowId, book, previousDueDate, newDueDate, renewalNumber }) {
  await pool.execute(
    `INSERT INTO renewals (issue_id, student_id, book_id, previous_due_date, new_due_date, renewal_number, method, status)
     VALUES (?, ?, ?, ?, ?, ?, 'self_service', 'approved')`,
    [issueId, studentRowId, book.id, previousDueDate, newDueDate, renewalNumber]
  );
}

async function addFine({ studentRowId, issueId, amount, reason, status = 'unpaid' }) {
  await pool.execute(
    `INSERT INTO fines (student_id, issue_id, amount, reason, status) VALUES (?, ?, ?, ?, ?)`,
    [studentRowId, issueId, amount, reason, status]
  );
}

async function addReservation({ studentRowId, book }) {
  await pool.execute(
    `INSERT INTO reservations (student_id, book_id, status) VALUES (?, ?, 'active')`,
    [studentRowId, book.id]
  );
}

async function addNotification({ userId, type, title, message }) {
  await pool.execute(
    `INSERT INTO notifications (user_id, type, title, message) VALUES (?, ?, ?, ?)`,
    [userId, type, title, message]
  );
}

async function run() {
  console.log('\n[seed] Starting SmartLib AI database seed...\n');
  await wipeExisting();
  await seedSettings();

  const categoryNames = [
    'Programming', 'Data Structures & Algorithms', 'Database Systems', 'Operating Systems',
    'Networking', 'Web Development', 'Artificial Intelligence', 'Machine Learning',
    'Cyber Security', 'Computer Organization',
  ];
  const catIds = await seedCategories(categoryNames);
  const books = await seedBooks(catIds);

  // ---- Admin ----
  await createUser({ name: 'Meera Nair', email: 'admin@smartlib.ai', role: 'admin' });
  console.log('[seed] admin account created -> admin@smartlib.ai / ' + ADMIN_PASSWORD);

  // ---- Student 1: Aarav Sharma — the main demo account (spec section 50) ----
  const s1 = await createUser({
    name: 'Aarav Sharma',
    email: `student1${env.COLLEGE_EMAIL_DOMAIN}`,
    role: 'student',
    studentFields: { studentId: 'CS2024001', course: 'BCA', semester: '5', department: 'Computer Science' },
  });

  const s1Dbms = await issueDirect({ studentRowId: s1.studentRowId, book: books['Database Management Systems'], daysAgoIssued: 28, daysUntilDue: 2 });
  await addNotification({ userId: s1.userId, type: 'due_soon', title: 'Book due soon', message: `Your "Database Management Systems" book is due in 2 days.` });

  const s1Cn = await issueDirect({ studentRowId: s1.studentRowId, book: books['Computer Networks'], daysAgoIssued: 10, daysUntilDue: 20 });

  const s1Os = await issueDirect({ studentRowId: s1.studentRowId, book: books['Operating System Concepts'], daysAgoIssued: 35, daysUntilDue: 25, renewalCount: 1 });
  await addRenewal({
    issueId: s1Os.issueId, studentRowId: s1.studentRowId, book: books['Operating System Concepts'],
    previousDueDate: dateUtils.addDays(dateUtils.todayISO(), -5), newDueDate: s1Os.dueDate, renewalNumber: 1,
  });
  await addNotification({ userId: s1.userId, type: 'renewed', title: 'Book renewed', message: `"Operating System Concepts" has been renewed. New due date: ${dateUtils.formatDisplay(s1Os.dueDate)}.` });

  console.log(`[seed] student1 (Aarav Sharma) -> student1${env.COLLEGE_EMAIL_DOMAIN} / ${PASSWORD} — 3 books issued, 1 due soon, \u20b90 fine`);

  // ---- Student 2: Isha Verma — overdue + an unpaid fine on file ----
  const s2 = await createUser({
    name: 'Isha Verma',
    email: `student2${env.COLLEGE_EMAIL_DOMAIN}`,
    role: 'student',
    studentFields: { studentId: 'CS2024002', course: 'BCA', semester: '5', department: 'Computer Science' },
  });

  await issueDirect({ studentRowId: s2.studentRowId, book: books['Let Us C'], daysAgoIssued: 12, daysUntilDue: 18 });

  const s2Overdue = await issueDirect({ studentRowId: s2.studentRowId, book: books['Cryptography and Network Security'], daysAgoIssued: 40, daysUntilDue: -10, status: 'overdue' });
  await addNotification({ userId: s2.userId, type: 'overdue', title: 'Overdue book', message: `Your "Cryptography and Network Security" book is overdue. Please return it as soon as possible.` });

  const s2Returned = await issueDirect({ studentRowId: s2.studentRowId, book: books['Machine Learning'], daysAgoIssued: 60, daysUntilDue: -30, returnedDaysAgo: 25 });
  await addFine({ studentRowId: s2.studentRowId, issueId: s2Returned.issueId, amount: 25, reason: 'Overdue return — 5 day(s) late' });
  await addNotification({ userId: s2.userId, type: 'fine', title: 'Fine applied', message: `A fine of \u20b925 was applied for returning "Machine Learning" 5 day(s) late.` });

  console.log(`[seed] student2 (Isha Verma) -> student2${env.COLLEGE_EMAIL_DOMAIN} / ${PASSWORD} — 1 active, 1 overdue, ₹25 unpaid fine`);

  // ---- Student 3: Rohan Gupta — empty state + an active reservation ----
  const s3 = await createUser({
    name: 'Rohan Gupta',
    email: `student3${env.COLLEGE_EMAIL_DOMAIN}`,
    role: 'student',
    studentFields: { studentId: 'CS2024003', course: 'BCA', semester: '3', department: 'Computer Science' },
  });

  await addReservation({ studentRowId: s3.studentRowId, book: books['Let Us C'] }); // Let Us C has 1 copy, already with student2
  await addNotification({ userId: s3.userId, type: 'system', title: 'Welcome to SmartLib AI', message: 'Your account is verified and ready. Browse the catalog to get started.' });

  console.log(`[seed] student3 (Rohan Gupta) -> student3${env.COLLEGE_EMAIL_DOMAIN} / ${PASSWORD} — no books issued, 1 active reservation`);

  console.log('\n[seed] Done. Demo credentials:');
  console.log(`  Admin:    admin@smartlib.ai / ${ADMIN_PASSWORD}`);
  console.log(`  Student1: student1${env.COLLEGE_EMAIL_DOMAIN} / ${PASSWORD}  (3 books, 1 due soon)`);
  console.log(`  Student2: student2${env.COLLEGE_EMAIL_DOMAIN} / ${PASSWORD}  (1 overdue, ₹25 unpaid fine)`);
  console.log(`  Student3: student3${env.COLLEGE_EMAIL_DOMAIN} / ${PASSWORD}  (empty state, 1 reservation)\n`);

  await pool.end();
}

run().catch((err) => {
  console.error('[seed] FAILED:', err);
  process.exit(1);
});
