// backend/models/verificationModel.js
const { pool } = require('../config/db');

async function create(conn, { userId, codeHash, purpose, expiresAt }) {
  const executor = conn || pool;
  const [result] = await executor.execute(
    `INSERT INTO email_verifications (user_id, code_hash, purpose, expires_at) VALUES (?, ?, ?, ?)`,
    [userId, codeHash, purpose, expiresAt]
  );
  return result.insertId;
}

// Latest unconsumed, unexpired record for a user + purpose.
async function findActive(userId, purpose) {
  const [rows] = await pool.execute(
    `SELECT * FROM email_verifications
     WHERE user_id = ? AND purpose = ? AND consumed_at IS NULL AND expires_at > NOW()
     ORDER BY created_at DESC LIMIT 1`,
    [userId, purpose]
  );
  return rows[0] || null;
}

async function consume(id) {
  await pool.execute(`UPDATE email_verifications SET consumed_at = NOW() WHERE id = ?`, [id]);
}

module.exports = { create, findActive, consume };
