// backend/models/reservationModel.js
const { pool } = require('../config/db');

const BASE_SELECT = `
  SELECT r.*, b.title, b.author, b.book_id AS book_code, b.cover_image,
         s.student_id AS student_code, u.name AS student_name, u.id AS student_user_id
  FROM reservations r
  JOIN books b ON b.id = r.book_id
  JOIN students s ON s.id = r.student_id
  JOIN users u ON u.id = s.user_id
`;

async function findActiveByStudentAndBook(studentId, bookId) {
  const [rows] = await pool.execute(
    `SELECT * FROM reservations WHERE student_id = ? AND book_id = ? AND status = 'active' LIMIT 1`,
    [studentId, bookId]
  );
  return rows[0] || null;
}

async function create(studentId, bookId) {
  const [result] = await pool.execute(
    `INSERT INTO reservations (student_id, book_id, status) VALUES (?, ?, 'active')`,
    [studentId, bookId]
  );
  return result.insertId;
}

async function findByStudent(studentId) {
  const [rows] = await pool.execute(
    `${BASE_SELECT} WHERE r.student_id = ? ORDER BY r.reserved_at DESC`,
    [studentId]
  );
  return rows;
}

async function findAll({ status, limit = 100, offset = 0 } = {}) {
  const clauses = [];
  const values = [];
  if (status) {
    clauses.push('r.status = ?');
    values.push(status);
  }
  const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
  values.push(limit, offset);
  const [rows] = await pool.execute(`${BASE_SELECT} ${where} ORDER BY r.reserved_at DESC LIMIT ? OFFSET ?`, values);
  return rows;
}

// The earliest active reservation for a book (first-come-first-served queue).
async function nextInQueue(conn, bookId) {
  const executor = conn || pool;
  const [rows] = await executor.execute(
    `SELECT * FROM reservations WHERE book_id = ? AND status = 'active' ORDER BY reserved_at ASC LIMIT 1`,
    [bookId]
  );
  return rows[0] || null;
}

async function cancel(id, studentId) {
  const [result] = await pool.execute(
    `UPDATE reservations SET status = 'cancelled' WHERE id = ? AND student_id = ? AND status = 'active'`,
    [id, studentId]
  );
  return result.affectedRows > 0;
}

async function markNotified(conn, id) {
  const executor = conn || pool;
  await executor.execute(`UPDATE reservations SET status = 'fulfilled', notified_at = NOW(), fulfilled_at = NOW() WHERE id = ?`, [id]);
}

async function countActiveForBook(bookId) {
  const [rows] = await pool.execute(
    `SELECT COUNT(*) AS count FROM reservations WHERE book_id = ? AND status = 'active'`,
    [bookId]
  );
  return rows[0].count;
}

async function isReservedByAnotherStudent(bookId, studentId) {
  const [rows] = await pool.execute(
    `SELECT COUNT(*) AS count FROM reservations WHERE book_id = ? AND status = 'active' AND student_id != ?`,
    [bookId, studentId]
  );
  return rows[0].count > 0;
}

module.exports = {
  findActiveByStudentAndBook, create, findByStudent, findAll,
  nextInQueue, cancel, markNotified, countActiveForBook, isReservedByAnotherStudent,
};
