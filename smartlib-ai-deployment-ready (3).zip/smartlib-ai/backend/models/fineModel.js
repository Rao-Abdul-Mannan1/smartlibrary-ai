// backend/models/fineModel.js
const { pool } = require('../config/db');

const BASE_SELECT = `
  SELECT f.*, b.title, b.book_id AS book_code, s.student_id AS student_code, u.name AS student_name
  FROM fines f
  JOIN issues i ON i.id = f.issue_id
  JOIN books b ON b.id = i.book_id
  JOIN students s ON s.id = f.student_id
  JOIN users u ON u.id = s.user_id
`;

async function create(conn, { studentId, issueId, amount, reason }) {
  const executor = conn || pool;
  const [result] = await executor.execute(
    `INSERT INTO fines (student_id, issue_id, amount, reason, status) VALUES (?, ?, ?, ?, 'unpaid')`,
    [studentId, issueId, amount, reason]
  );
  return result.insertId;
}

async function findByStudent(studentId) {
  const [rows] = await pool.execute(
    `${BASE_SELECT} WHERE f.student_id = ? ORDER BY f.created_at DESC`,
    [studentId]
  );
  return rows;
}

async function totalUnpaidByStudent(studentId) {
  const [rows] = await pool.execute(
    `SELECT COALESCE(SUM(amount), 0) AS total FROM fines WHERE student_id = ? AND status = 'unpaid'`,
    [studentId]
  );
  return Number(rows[0].total);
}

async function findAll({ status, limit = 100, offset = 0 } = {}) {
  const clauses = [];
  const values = [];
  if (status) {
    clauses.push('f.status = ?');
    values.push(status);
  }
  const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
  values.push(limit, offset);
  const [rows] = await pool.execute(`${BASE_SELECT} ${where} ORDER BY f.created_at DESC LIMIT ? OFFSET ?`, values);
  return rows;
}

async function findById(id) {
  const [rows] = await pool.execute(`${BASE_SELECT} WHERE f.id = ? LIMIT 1`, [id]);
  return rows[0] || null;
}

async function updateStatus(id, status) {
  const paidAt = status === 'paid' ? new Date() : null;
  await pool.execute('UPDATE fines SET status = ?, paid_at = ? WHERE id = ?', [status, paidAt, id]);
}

async function totalCollected() {
  const [rows] = await pool.execute("SELECT COALESCE(SUM(amount), 0) AS total FROM fines WHERE status = 'paid'");
  return Number(rows[0].total);
}

async function totalOutstanding() {
  const [rows] = await pool.execute("SELECT COALESCE(SUM(amount), 0) AS total FROM fines WHERE status = 'unpaid'");
  return Number(rows[0].total);
}

module.exports = {
  create, findByStudent, totalUnpaidByStudent, findAll, findById,
  updateStatus, totalCollected, totalOutstanding,
};
