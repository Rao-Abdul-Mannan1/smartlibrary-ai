// backend/models/userModel.js
const { pool } = require('../config/db');

async function findByEmail(email) {
  const [rows] = await pool.execute('SELECT * FROM users WHERE email = ? LIMIT 1', [email]);
  return rows[0] || null;
}

async function findById(id) {
  const [rows] = await pool.execute('SELECT * FROM users WHERE id = ? LIMIT 1', [id]);
  return rows[0] || null;
}

async function create(conn, { name, email, passwordHash, role }) {
  const executor = conn || pool;
  const [result] = await executor.execute(
    'INSERT INTO users (name, email, password_hash, role, status, email_verified) VALUES (?, ?, ?, ?, ?, ?)',
    [name, email, passwordHash, role, 'pending', 0]
  );
  return result.insertId;
}

async function markEmailVerified(userId) {
  await pool.execute("UPDATE users SET email_verified = 1, status = 'active' WHERE id = ?", [userId]);
}

async function updatePassword(userId, passwordHash) {
  await pool.execute('UPDATE users SET password_hash = ? WHERE id = ?', [passwordHash, userId]);
}

async function setStatus(userId, status) {
  await pool.execute('UPDATE users SET status = ? WHERE id = ?', [status, userId]);
}

async function updateProfile(userId, { name }) {
  await pool.execute('UPDATE users SET name = ? WHERE id = ?', [name, userId]);
}

async function countByRole(role) {
  const [rows] = await pool.execute('SELECT COUNT(*) AS count FROM users WHERE role = ?', [role]);
  return rows[0].count;
}

module.exports = {
  findByEmail,
  findById,
  create,
  markEmailVerified,
  updatePassword,
  setStatus,
  updateProfile,
  countByRole,
};
