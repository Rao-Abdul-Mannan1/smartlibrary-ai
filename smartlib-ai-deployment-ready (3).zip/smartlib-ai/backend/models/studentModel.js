// backend/models/studentModel.js
const { pool } = require('../config/db');

async function create(conn, { userId, studentId, course, semester, department }) {
  const executor = conn || pool;
  const [result] = await executor.execute(
    'INSERT INTO students (user_id, student_id, course, semester, department) VALUES (?, ?, ?, ?, ?)',
    [userId, studentId, course || null, semester || null, department || null]
  );
  return result.insertId;
}

// Returns the student row joined with core user fields — the shape
// used throughout the app to represent "the logged-in student".
async function findByUserId(userId) {
  const [rows] = await pool.execute(
    `SELECT s.*, u.name, u.email, u.status AS account_status, u.email_verified
     FROM students s JOIN users u ON u.id = s.user_id
     WHERE s.user_id = ? LIMIT 1`,
    [userId]
  );
  return rows[0] || null;
}

async function findById(studentRowId) {
  const [rows] = await pool.execute(
    `SELECT s.*, u.name, u.email, u.status AS account_status, u.email_verified
     FROM students s JOIN users u ON u.id = s.user_id
     WHERE s.id = ? LIMIT 1`,
    [studentRowId]
  );
  return rows[0] || null;
}

async function search(query, limit = 50) {
  const like = `%${query}%`;
  const [rows] = await pool.execute(
    `SELECT s.id, s.student_id, s.course, s.department, u.name, u.email, u.status
     FROM students s JOIN users u ON u.id = s.user_id
     WHERE u.name LIKE ? OR u.email LIKE ? OR s.student_id LIKE ?
     ORDER BY u.name ASC LIMIT ?`,
    [like, like, like, limit]
  );
  return rows;
}

async function listAll({ limit = 50, offset = 0 } = {}) {
  const [rows] = await pool.execute(
    `SELECT s.id, s.student_id, s.course, s.department, s.semester, u.name, u.email, u.status, u.email_verified
     FROM students s JOIN users u ON u.id = s.user_id
     ORDER BY u.created_at DESC LIMIT ? OFFSET ?`,
    [limit, offset]
  );
  return rows;
}

async function count() {
  const [rows] = await pool.execute('SELECT COUNT(*) AS count FROM students');
  return rows[0].count;
}

module.exports = { create, findByUserId, findById, search, listAll, count };
