// backend/models/aiModel.js
const { pool } = require('../config/db');

async function createConversation(studentId, title = 'New conversation') {
  const [result] = await pool.execute(
    `INSERT INTO ai_conversations (student_id, title) VALUES (?, ?)`,
    [studentId, title]
  );
  return result.insertId;
}

async function findConversation(id, studentId) {
  const [rows] = await pool.execute(
    `SELECT * FROM ai_conversations WHERE id = ? AND student_id = ? LIMIT 1`,
    [id, studentId]
  );
  return rows[0] || null;
}

async function latestConversation(studentId) {
  const [rows] = await pool.execute(
    `SELECT * FROM ai_conversations WHERE student_id = ? ORDER BY updated_at DESC LIMIT 1`,
    [studentId]
  );
  return rows[0] || null;
}

async function touchConversation(id) {
  await pool.execute(`UPDATE ai_conversations SET updated_at = NOW() WHERE id = ?`, [id]);
}

async function addMessage(conversationId, role, content, toolCalls = null) {
  const [result] = await pool.execute(
    `INSERT INTO ai_messages (conversation_id, role, content, tool_calls) VALUES (?, ?, ?, ?)`,
    [conversationId, role, content, toolCalls ? JSON.stringify(toolCalls) : null]
  );
  return result.insertId;
}

async function getMessages(conversationId, limit = 20) {
  const [rows] = await pool.execute(
    `SELECT * FROM ai_messages WHERE conversation_id = ? ORDER BY created_at ASC LIMIT ?`,
    [conversationId, limit]
  );
  return rows;
}

module.exports = { createConversation, findConversation, latestConversation, touchConversation, addMessage, getMessages };
