// backend/models/issueModel.js
const { pool } = require('../config/db');

const BASE_SELECT = `
  SELECT i.*, b.book_id AS book_code, b.title, b.author, b.cover_image, b.isbn,
         s.student_id AS student_code, u.name AS student_name, u.email AS student_email
  FROM issues i
  JOIN books b ON b.id = i.book_id
  JOIN students s ON s.id = i.student_id
  JOIN users u ON u.id = s.user_id
`;

async function findById(id) {
  const [rows] = await pool.execute(`${BASE_SELECT} WHERE i.id = ? LIMIT 1`, [id]);
  return rows[0] || null;
}

// All non-returned issues for a student, most urgent due date first.
async function findActiveByStudent(studentId) {
  const [rows] = await pool.execute(
    `${BASE_SELECT} WHERE i.student_id = ? AND i.status IN ('active','overdue') ORDER BY i.due_date ASC`,
    [studentId]
  );
  return rows;
}

async function findActiveByStudentAndBook(studentId, bookId) {
  const [rows] = await pool.execute(
    `${BASE_SELECT} WHERE i.student_id = ? AND i.book_id = ? AND i.status IN ('active','overdue')
     ORDER BY i.due_date ASC LIMIT 1`,
    [studentId, bookId]
  );
  return rows[0] || null;
}

async function findHistoryByStudent(studentId, { limit = 50, offset = 0 } = {}) {
  const [rows] = await pool.execute(
    `${BASE_SELECT} WHERE i.student_id = ? ORDER BY i.issue_date DESC LIMIT ? OFFSET ?`,
    [studentId, limit, offset]
  );
  return rows;
}

async function hasAnyOverdue(studentId, excludeIssueId = null) {
  const clauses = ["i.student_id = ?", "i.status IN ('active','overdue')", "i.due_date < CURDATE()"];
  const values = [studentId];
  if (excludeIssueId) {
    clauses.push('i.id != ?');
    values.push(excludeIssueId);
  }
  const [rows] = await pool.execute(
    `SELECT COUNT(*) AS count FROM issues i WHERE ${clauses.join(' AND ')}`,
    values
  );
  return rows[0].count > 0;
}

// Create an issue row. Must be called inside a transaction alongside
// bookModel.adjustAvailability(conn, bookId, -1).
async function create(conn, { studentId, bookId, issueDate, dueDate, issuedBy = null }) {
  const executor = conn || pool;
  const [result] = await executor.execute(
    `INSERT INTO issues (student_id, book_id, issue_date, due_date, status, issued_by)
     VALUES (?, ?, ?, ?, 'active', ?)`,
    [studentId, bookId, issueDate, dueDate, issuedBy]
  );
  return result.insertId;
}

async function applyRenewal(conn, issueId, newDueDate) {
  const executor = conn || pool;
  await executor.execute(
    `UPDATE issues SET due_date = ?, renewal_count = renewal_count + 1, status = 'active' WHERE id = ?`,
    [newDueDate, issueId]
  );
}

async function markReturned(conn, issueId, returnedDate, returnedTo = null) {
  const executor = conn || pool;
  await executor.execute(
    `UPDATE issues SET status = 'returned', returned_date = ?, returned_to = ? WHERE id = ?`,
    [returnedDate, returnedTo, issueId]
  );
}

// Sweep job: flip any active issue past its due date to 'overdue'.
// Safe to call frequently — pure status bookkeeping, no side effects on fines.
async function markOverdueSweep() {
  const [result] = await pool.execute(
    `UPDATE issues SET status = 'overdue' WHERE status = 'active' AND due_date < CURDATE()`
  );
  return result.affectedRows;
}

async function countActive() {
  const [rows] = await pool.execute("SELECT COUNT(*) AS count FROM issues WHERE status IN ('active','overdue')");
  return rows[0].count;
}

async function countOverdue() {
  const [rows] = await pool.execute(
    "SELECT COUNT(*) AS count FROM issues WHERE status IN ('active','overdue') AND due_date < CURDATE()"
  );
  return rows[0].count;
}

async function countDueSoon(studentId, withinDays = 3) {
  const [rows] = await pool.execute(
    `SELECT COUNT(*) AS count FROM issues
     WHERE student_id = ? AND status = 'active'
       AND due_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL ? DAY)`,
    [studentId, withinDays]
  );
  return rows[0].count;
}

async function monthlyStats(months = 6) {
  const [rows] = await pool.execute(
    `SELECT DATE_FORMAT(issue_date, '%Y-%m') AS month, COUNT(*) AS total
     FROM issues
     WHERE issue_date >= DATE_SUB(CURDATE(), INTERVAL ? MONTH)
     GROUP BY month ORDER BY month ASC`,
    [months]
  );
  return rows;
}

async function monthlyReturns(months = 6) {
  const [rows] = await pool.execute(
    `SELECT DATE_FORMAT(returned_date, '%Y-%m') AS month, COUNT(*) AS total
     FROM issues
     WHERE returned_date IS NOT NULL AND returned_date >= DATE_SUB(CURDATE(), INTERVAL ? MONTH)
     GROUP BY month ORDER BY month ASC`,
    [months]
  );
  return rows;
}

async function overdueList({ limit = 100 } = {}) {
  const [rows] = await pool.execute(
    `${BASE_SELECT} WHERE i.status IN ('active','overdue') AND i.due_date < CURDATE()
     ORDER BY i.due_date ASC LIMIT ?`,
    [limit]
  );
  return rows;
}

module.exports = {
  findById, findActiveByStudent, findActiveByStudentAndBook, findHistoryByStudent,
  hasAnyOverdue, create, applyRenewal, markReturned, markOverdueSweep,
  countActive, countOverdue, countDueSoon, monthlyStats, monthlyReturns, overdueList,
};
