// backend/models/notificationModel.js
const { pool } = require('../config/db');

async function create(conn, { userId, type = 'general', title, message }) {
  const executor = conn || pool;
  const [result] = await executor.execute(
    `INSERT INTO notifications (user_id, type, title, message) VALUES (?, ?, ?, ?)`,
    [userId, type, title, message]
  );
  return result.insertId;
}

async function findByUser(userId, { limit = 30, offset = 0 } = {}) {
  const [rows] = await pool.execute(
    `SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?`,
    [userId, limit, offset]
  );
  return rows;
}

async function unreadCount(userId) {
  const [rows] = await pool.execute(
    `SELECT COUNT(*) AS count FROM notifications WHERE user_id = ? AND is_read = 0`,
    [userId]
  );
  return rows[0].count;
}

async function markRead(id, userId) {
  await pool.execute(`UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?`, [id, userId]);
}

async function markAllRead(userId) {
  await pool.execute(`UPDATE notifications SET is_read = 1 WHERE user_id = ?`, [userId]);
}

module.exports = { create, findByUser, unreadCount, markRead, markAllRead };
