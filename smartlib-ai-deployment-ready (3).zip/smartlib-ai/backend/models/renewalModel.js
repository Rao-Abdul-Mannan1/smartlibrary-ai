// backend/models/renewalModel.js
const { pool } = require('../config/db');

const BASE_SELECT = `
  SELECT r.*, b.book_id AS book_code, b.title, s.student_id AS student_code, u.name AS student_name
  FROM renewals r
  JOIN books b ON b.id = r.book_id
  JOIN students s ON s.id = r.student_id
  JOIN users u ON u.id = s.user_id
`;

async function record(conn, {
  issueId, studentId, bookId, previousDueDate, newDueDate,
  renewalNumber, method = 'self_service', performedBy = null,
}) {
  const executor = conn || pool;
  const [result] = await executor.execute(
    `INSERT INTO renewals
      (issue_id, student_id, book_id, previous_due_date, new_due_date, renewal_number, method, status, performed_by)
     VALUES (?, ?, ?, ?, ?, ?, ?, 'approved', ?)`,
    [issueId, studentId, bookId, previousDueDate, newDueDate, renewalNumber, method, performedBy]
  );
  return result.insertId;
}

async function findByStudent(studentId, { limit = 50, offset = 0 } = {}) {
  const [rows] = await pool.execute(
    `${BASE_SELECT} WHERE r.student_id = ? ORDER BY r.created_at DESC LIMIT ? OFFSET ?`,
    [studentId, limit, offset]
  );
  return rows;
}

async function findAll({ method, limit = 100, offset = 0 } = {}) {
  const clauses = [];
  const values = [];
  if (method) {
    clauses.push('r.method = ?');
    values.push(method);
  }
  const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
  values.push(limit, offset);
  const [rows] = await pool.execute(
    `${BASE_SELECT} ${where} ORDER BY r.created_at DESC LIMIT ? OFFSET ?`,
    values
  );
  return rows;
}

async function monthlyStats(months = 6) {
  const [rows] = await pool.execute(
    `SELECT DATE_FORMAT(created_at, '%Y-%m') AS month, COUNT(*) AS total
     FROM renewals
     WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL ? MONTH)
     GROUP BY month ORDER BY month ASC`,
    [months]
  );
  return rows;
}

async function countTotal() {
  const [rows] = await pool.execute('SELECT COUNT(*) AS count FROM renewals');
  return rows[0].count;
}

module.exports = { record, findByStudent, findAll, monthlyStats, countTotal };
