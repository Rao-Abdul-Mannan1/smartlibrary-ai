// backend/models/settingsModel.js
// library_settings is a simple key/value table so admins can change
// borrowing rules without a code deployment (see backend/services/renewalService.js).
const { pool } = require('../config/db');

const DEFAULTS = {
  max_books_per_student: '5',
  max_renewals_per_book: '2',
  renewal_period_days: '30',
  loan_period_days: '30',
  fine_per_day: '5',
  max_unpaid_fine_allowed: '100',
  due_soon_threshold_days: '3',
};

async function getAll() {
  const [rows] = await pool.execute('SELECT setting_key, setting_value, description FROM library_settings');
  const settings = { ...DEFAULTS };
  for (const row of rows) settings[row.setting_key] = row.setting_value;
  return settings;
}

async function getNumber(key) {
  const all = await getAll();
  return Number(all[key] ?? DEFAULTS[key] ?? 0);
}

async function upsertMany(pairs) {
  // pairs: { key: value, ... }
  const entries = Object.entries(pairs);
  for (const [key, value] of entries) {
    await pool.execute(
      `INSERT INTO library_settings (setting_key, setting_value) VALUES (?, ?)
       ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)`,
      [key, String(value)]
    );
  }
}

module.exports = { getAll, getNumber, upsertMany, DEFAULTS };
