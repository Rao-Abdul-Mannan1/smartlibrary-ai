// backend/models/bookModel.js
const { pool } = require('../config/db');

const BASE_SELECT = `
  SELECT b.*, c.name AS category_name
  FROM books b LEFT JOIN categories c ON c.id = b.category_id
`;

async function findById(id) {
  const [rows] = await pool.execute(`${BASE_SELECT} WHERE b.id = ? LIMIT 1`, [id]);
  return rows[0] || null;
}

async function findByBookId(bookId) {
  const [rows] = await pool.execute(`${BASE_SELECT} WHERE b.book_id = ? LIMIT 1`, [bookId]);
  return rows[0] || null;
}

async function findByIsbn(isbn) {
  const [rows] = await pool.execute(`${BASE_SELECT} WHERE b.isbn = ? LIMIT 1`, [isbn]);
  return rows[0] || null;
}

// Generates the next sequential BK-#### id, e.g. BK-1001, BK-1002, ...
async function nextBookId() {
  const [rows] = await pool.execute(
    "SELECT book_id FROM books WHERE book_id LIKE 'BK-%' ORDER BY id DESC LIMIT 1"
  );
  if (!rows[0]) return 'BK-1001';
  const n = parseInt(rows[0].book_id.replace('BK-', ''), 10) || 1000;
  return `BK-${n + 1}`;
}

async function create(fields) {
  const {
    bookId, isbn, title, author, publisher, edition, categoryId,
    description, coverImage, shelfNumber, quantity,
  } = fields;
  const [result] = await pool.execute(
    `INSERT INTO books
      (book_id, isbn, title, author, publisher, edition, category_id, description, cover_image, shelf_number, quantity, available_quantity)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [bookId, isbn || null, title, author, publisher || null, edition || null, categoryId || null,
     description || null, coverImage || null, shelfNumber || null, quantity, quantity]
  );
  return result.insertId;
}

async function setQrImage(id, qrImagePath) {
  await pool.execute('UPDATE books SET qr_image = ? WHERE id = ?', [qrImagePath, id]);
}

async function update(id, fields) {
  const allowed = ['isbn', 'title', 'author', 'publisher', 'edition', 'category_id',
    'description', 'cover_image', 'shelf_number', 'quantity', 'available_quantity', 'is_active'];
  const sets = [];
  const values = [];
  for (const key of allowed) {
    if (Object.prototype.hasOwnProperty.call(fields, key)) {
      sets.push(`${key} = ?`);
      values.push(fields[key]);
    }
  }
  if (sets.length === 0) return;
  values.push(id);
  await pool.execute(`UPDATE books SET ${sets.join(', ')} WHERE id = ?`, values);
}

async function softDelete(id) {
  await pool.execute('UPDATE books SET is_active = 0 WHERE id = ?', [id]);
}

// Adjust available_quantity by delta (+1 on return, -1 on issue). Must run inside a transaction.
async function adjustAvailability(conn, bookId, delta) {
  await conn.execute(
    'UPDATE books SET available_quantity = available_quantity + ? WHERE id = ?',
    [delta, bookId]
  );
}

async function search({ q, category, availability, author, limit = 30, offset = 0 } = {}) {
  const clauses = ['b.is_active = 1'];
  const values = [];

  if (q) {
    clauses.push('(b.title LIKE ? OR b.author LIKE ? OR b.isbn LIKE ? OR b.publisher LIKE ? OR c.name LIKE ?)');
    const like = `%${q}%`;
    values.push(like, like, like, like, like);
  }
  if (category) {
    clauses.push('c.name = ?');
    values.push(category);
  }
  if (author) {
    clauses.push('b.author LIKE ?');
    values.push(`%${author}%`);
  }
  if (availability === 'available') {
    clauses.push('b.available_quantity > 0');
  } else if (availability === 'issued') {
    clauses.push('b.available_quantity = 0');
  }

  const sql = `${BASE_SELECT} WHERE ${clauses.join(' AND ')} ORDER BY b.title ASC LIMIT ? OFFSET ?`;
  values.push(limit, offset);
  const [rows] = await pool.execute(sql, values);
  return rows;
}

async function listAll({ limit = 50, offset = 0 } = {}) {
  const [rows] = await pool.execute(
    `${BASE_SELECT} WHERE b.is_active = 1 ORDER BY b.created_at DESC LIMIT ? OFFSET ?`,
    [limit, offset]
  );
  return rows;
}

async function listCategories() {
  const [rows] = await pool.execute('SELECT * FROM categories ORDER BY name ASC');
  return rows;
}

async function findOrCreateCategory(conn, name) {
  const executor = conn || pool;
  const [rows] = await executor.execute('SELECT id FROM categories WHERE name = ? LIMIT 1', [name]);
  if (rows[0]) return rows[0].id;
  const [result] = await executor.execute('INSERT INTO categories (name) VALUES (?)', [name]);
  return result.insertId;
}

async function countTotal() {
  const [rows] = await pool.execute('SELECT COUNT(*) AS count FROM books WHERE is_active = 1');
  return rows[0].count;
}

async function countAvailable() {
  const [rows] = await pool.execute('SELECT COALESCE(SUM(available_quantity), 0) AS count FROM books WHERE is_active = 1');
  return rows[0].count;
}

async function countIssuedCopies() {
  const [rows] = await pool.execute(
    'SELECT COALESCE(SUM(quantity - available_quantity), 0) AS count FROM books WHERE is_active = 1'
  );
  return rows[0].count;
}

// Simple content-based recommender: same category as the given book(s),
// excluding books the student already has, ranked by popularity (times issued).
async function recommendSimilar(categoryIds, excludeBookIds = [], limit = 5) {
  if (!categoryIds.length) return [];
  const catPlaceholders = categoryIds.map(() => '?').join(',');
  const excludeClause = excludeBookIds.length
    ? `AND b.id NOT IN (${excludeBookIds.map(() => '?').join(',')})`
    : '';
  const sql = `
    SELECT b.*, c.name AS category_name, COUNT(i.id) AS times_issued
    FROM books b
    LEFT JOIN categories c ON c.id = b.category_id
    LEFT JOIN issues i ON i.book_id = b.id
    WHERE b.category_id IN (${catPlaceholders}) AND b.is_active = 1 ${excludeClause}
    GROUP BY b.id
    ORDER BY times_issued DESC, b.title ASC
    LIMIT ?
  `;
  const values = [...categoryIds, ...excludeBookIds, limit];
  const [rows] = await pool.execute(sql, values);
  return rows;
}

async function mostBorrowed(limit = 10, sinceDate = null) {
  const values = [];
  let dateClause = '';
  if (sinceDate) {
    dateClause = 'WHERE i.issue_date >= ?';
    values.push(sinceDate);
  }
  const sql = `
    SELECT b.id, b.book_id, b.title, b.author, COUNT(i.id) AS times_issued
    FROM issues i JOIN books b ON b.id = i.book_id
    ${dateClause}
    GROUP BY b.id
    ORDER BY times_issued DESC
    LIMIT ?
  `;
  values.push(limit);
  const [rows] = await pool.execute(sql, values);
  return rows;
}

async function categoryDistribution() {
  const [rows] = await pool.execute(`
    SELECT COALESCE(c.name, 'Uncategorized') AS category, COUNT(b.id) AS book_count
    FROM books b LEFT JOIN categories c ON c.id = b.category_id
    WHERE b.is_active = 1
    GROUP BY category ORDER BY book_count DESC
  `);
  return rows;
}

module.exports = {
  findById, findByBookId, findByIsbn, nextBookId, create, setQrImage, update, softDelete,
  adjustAvailability, search, listAll, listCategories, findOrCreateCategory,
  countTotal, countAvailable, countIssuedCopies, recommendSimilar, mostBorrowed, categoryDistribution,
};
