// backend/models/auditModel.js
const { pool } = require('../config/db');

async function log({ userId = null, action, target = null, details = null }) {
  await pool.execute(
    `INSERT INTO audit_logs (user_id, action, target, details) VALUES (?, ?, ?, ?)`,
    [userId, action, target, details ? JSON.stringify(details) : null]
  );
}

async function recent(limit = 100) {
  const [rows] = await pool.execute(
    `SELECT al.*, u.name AS user_name FROM audit_logs al LEFT JOIN users u ON u.id = al.user_id
     ORDER BY al.created_at DESC LIMIT ?`,
    [limit]
  );
  return rows;
}

module.exports = { log, recent };
