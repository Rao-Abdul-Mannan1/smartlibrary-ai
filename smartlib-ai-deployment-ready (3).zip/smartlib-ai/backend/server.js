// backend/server.js
// SmartLib AI — main server entry point.
// Run: npm start (production) or npm run dev (nodemon auto-reload)

const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const path = require('path');

const env = require('./config/env');
const { testConnection } = require('./config/db');
const { notFound, errorHandler } = require('./middleware/errorHandler');
const issueModel = require('./models/issueModel');

const authRoutes = require('./routes/authRoutes');
const bookRoutes = require('./routes/bookRoutes');
const studentRoutes = require('./routes/studentRoutes');
const adminRoutes = require('./routes/adminRoutes');
const renewalRoutes = require('./routes/renewalRoutes');
const fineRoutes = require('./routes/fineRoutes');
const reservationRoutes = require('./routes/reservationRoutes');
const notificationRoutes = require('./routes/notificationRoutes');
const aiRoutes = require('./routes/aiRoutes');
const reportRoutes = require('./routes/reportRoutes');
const settingsRoutes = require('./routes/settingsRoutes');

const app = express();

// Railway/Render/etc. sit behind a reverse proxy. This is needed for
// correct client IP handling in express-rate-limit and secure deployments.
app.set('trust proxy', 1);

// ---- Core middleware ----
const allowedOrigins = env.FRONTEND_URL
  ? env.FRONTEND_URL.split(',').map((origin) => origin.trim()).filter(Boolean)
  : [];

app.use(cors({
  origin(origin, callback) {
    // Same-origin browser requests and non-browser tools (curl/health checks)
    // do not send an Origin header and should be allowed.
    if (!origin) return callback(null, true);
    if (allowedOrigins.length === 0 || allowedOrigins.includes('*')) return callback(null, true);
    return callback(null, allowedOrigins.includes(origin));
  },
  credentials: false,
}));

// Lightweight security headers without adding another runtime dependency.
app.disable('x-powered-by');
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  if (req.secure) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  next();
});
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));
if (env.NODE_ENV !== 'test') app.use(morgan(env.NODE_ENV === 'development' ? 'dev' : 'combined'));

// Serve uploaded QR codes and book covers as static files.
app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));

// Serve the frontend itself, so the whole app (API + UI) can be reached
// from a single deployed URL — e.g. http://localhost:4000/ locally, or
// https://your-app.up.railway.app/ once deployed. Opening frontend/index.html
// directly via file:// still works too (see frontend/js/api.js).
app.use(express.static(path.join(__dirname, '..', 'frontend')));

// ---- Health check ----
app.get('/api/health', async (req, res) => {
  const connected = await testConnection();
  if (!connected) {
    return res.status(503).json({ success: false, error: { message: 'Database unavailable', code: 'DB_UNAVAILABLE' } });
  }
  return res.json({ success: true, data: { status: 'ok', time: new Date().toISOString() } });
});

// ---- API routes (matches spec section 32) ----
app.use('/api/auth', authRoutes);
app.use('/api/books', bookRoutes);
app.use('/api/student', studentRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/renewals', renewalRoutes);
app.use('/api/fines', fineRoutes);
app.use('/api/reservations', reservationRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/settings', settingsRoutes);

// ---- 404 + error handling (must be last) ----
app.use(notFound);
app.use(errorHandler);

// ---- Background sweep: flip active issues past due_date to 'overdue' ----
// Pure status bookkeeping (fines are calculated at return time, not here).
// Runs on boot and then hourly.
async function runOverdueSweep() {
  try {
    const count = await issueModel.markOverdueSweep();
    if (count > 0) console.log(`[sweep] marked ${count} issue(s) overdue`);
  } catch (err) {
    console.error('[sweep] failed:', err.message);
  }
}

async function start() {
  // Give a managed MySQL service a few seconds to become reachable during boot.
  let connected = false;
  for (let attempt = 1; attempt <= 10; attempt++) {
    connected = await testConnection();
    if (connected) break;
    if (attempt < 10) await new Promise((resolve) => setTimeout(resolve, 3000));
  }

  if (!connected) {
    console.error('[startup] Could not connect to MySQL after 10 attempts. Exiting.');
    process.exit(1);
  }

  await runOverdueSweep();
  setInterval(runOverdueSweep, 60 * 60 * 1000);

  const server = app.listen(env.PORT, () => {
    console.log(`\nSmartLib AI running on ${env.APP_URL}`);
    console.log(`Environment: ${env.NODE_ENV}`);
    console.log(`AI provider: ${env.AI_API_KEY ? env.AI_PROVIDER : 'none (basic mode)'}`);
  });

  const shutdown = (signal) => {
    console.log(`[shutdown] ${signal} received. Closing server...`);
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(1), 10000).unref();
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

start();

module.exports = app;
