// ai/tools/toolDefinitions.js
//
// JSON-schema definitions of the ONLY functions the AI is allowed to
// call. The AI never touches the database directly — every one of
// these is implemented in backend/services/aiTools.js as a plain,
// independently-callable, student-scoped function. The AI just decides
// *when* to call them and turns the result into natural language.
//
// Written in OpenAI "tools" format; toAiService() adapts the same
// definitions to Gemini's functionDeclarations shape so both providers
// share one source of truth.

const TOOLS = [
  {
    name: 'get_student_books',
    description: "Get the current student's currently issued (active/overdue) books, with due dates, renewal counts, and status.",
    parameters: { type: 'object', properties: {}, required: [] },
  },
  {
    name: 'get_book_details',
    description: 'Get full details of one book by its title (or partial title match) or its book_id (e.g. BK-1025).',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: "Book title, partial title, or book_id, e.g. 'DBMS' or 'BK-1025'." },
      },
      required: ['query'],
    },
  },
  {
    name: 'check_renewal_eligibility',
    description: 'Check whether a specific book currently issued to the student is eligible for renewal, and why/why not.',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: "Title, partial title, or book_id of one of the student's issued books." },
      },
      required: ['query'],
    },
  },
  {
    name: 'search_books',
    description: 'Search the library catalog by keyword, topic, category, or author. Use this for "find books about X" style requests.',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: 'Free-text search term, e.g. "cybersecurity" or "beginner C programming".' },
      },
      required: ['query'],
    },
  },
  {
    name: 'get_student_fines',
    description: "Get the current student's fines (paid, unpaid, waived) and total outstanding balance.",
    parameters: { type: 'object', properties: {}, required: [] },
  },
  {
    name: 'get_library_rules',
    description: 'Get the current configurable library rules: max books per student, max renewals per book, renewal period, fine per day, etc.',
    parameters: { type: 'object', properties: {}, required: [] },
  },
  {
    name: 'get_recommendations',
    description: "Get book recommendations for the student based on categories of books they've issued, or a stated interest/topic.",
    parameters: {
      type: 'object',
      properties: {
        topic: { type: 'string', description: 'Optional topic/interest to base recommendations on, e.g. "programming".' },
      },
      required: [],
    },
  },
];

function toOpenAiTools() {
  return TOOLS.map((t) => ({
    type: 'function',
    function: { name: t.name, description: t.description, parameters: t.parameters },
  }));
}

function toGeminiTools() {
  return [{ functionDeclarations: TOOLS.map((t) => ({ name: t.name, description: t.description, parameters: t.parameters })) }];
}

module.exports = { TOOLS, toOpenAiTools, toGeminiTools };
